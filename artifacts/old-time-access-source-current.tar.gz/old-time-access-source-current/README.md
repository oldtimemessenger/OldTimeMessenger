# Old Time — Access source snapshot

This bundle contains the exact current Access implementation from the Old Time workspace at export time. Access is Old Time's live audio-room / Current Events feature. It is a source snapshot, not a standalone app; the files are organized for review and download while preserving their original responsibilities.

## What Access is

Access lets people discover and join live conversations about current topics. A room has a host, optional moderators and speakers, and listeners. Users can raise a hand, be invited to speak, chat, react, send coin gifts, and share a room.

## User rules currently enforced

- Topics are: Politics, Markets, Tech, Culture, Sports, World, and For you in discovery.
- A room title is required and is limited to 120 characters.
- A room can be Public or Private.
- Public rooms allow anyone with an authenticated Old Time session to join.
- Private rooms reject non-host users at the join endpoint.
- A new participant joins as a muted listener.
- Only the host, moderator, or speaker role can publish audio.
- A listener can raise or lower their hand.
- Moderators can promote listeners, mute/unmute non-host participants, and remove participants through the participant action endpoint.
- The host can end the room. Ending a room marks it not live, removes current participants, deletes ephemeral room chat, and evicts connected clients.
- Room messages are ephemeral: they are deleted when the host ends the room.
- Reactions are realtime and rate-limited to 12 per socket per second.
- Gifts require a selected recipient and enough wallet Coins.
- Gift prices are currently: Coffee 25, Idea 100, Heart 200, Gem 500, Studio 1,000, and Time is up 10,000 Coins.
- Coin purchases are reconciled server-side from RevenueCat and each purchase is credited once by purchase ID.
- Gold is the creator-side reward ledger. Withdrawals require whole-dollar Gold amounts, a completed Stripe payout account, and a minimum of 900 Gold ($10 at 90 Gold per USD).
- The UI currently labels rooms as FREE; paid room-pricing controls are not active yet.
- Audio requires an internet connection and a configured LiveKit service. If LiveKit is not configured, the token endpoint returns an unavailable response and the room shows an audio error/retry state.
- All room routes require an authenticated Old Time session.

## Main files

### Mobile

- `mobile/map.tsx` — Access entry point from the Map and room routing.
- `mobile/current-events-home.tsx` — topic filters, live/trending sections, public/private room creation, and room cards.
- `mobile/current-event-room.tsx` — LiveKit connection, stage/listeners, hand raises, moderation, chat, reactions, gifts, wallet, sharing, and leave/end behavior.
- `mobile/audio-service.ts` and `mobile/audio-service.native.ts` — audio provider abstraction and native LiveKit audio connection.
- `mobile/livekit-globals*.ts` — LiveKit WebRTC global setup for native/web builds.
- `mobile/current-event-gifts.ts` and `assets/` — current gift catalog and media.
- `mobile/revenuecat.tsx` — mobile coin purchase and restore integration used by the room wallet.

### Server

- `server/current-events.ts` — room lifecycle, membership, LiveKit tokens, roles, chat, gifts, wallet reconciliation, creator payout setup, and withdrawals.
- `server/realtime.ts` and `server/index.ts` — authenticated Socket.IO room events for updates, messages, reactions, and gifts.
- `server/livekit.ts` — LiveKit token creation and configuration checks.
- `server/revenuecat.ts` — server-side purchase verification helpers.
- `server/app.ts` — API route mounting context.

### Database and contracts

- `database/current-events.ts` — rooms, participants, messages, wallets, gifts, coin purchases, payout accounts, and withdrawals.
- `database/0007_current_events.sql` — initial Access tables.
- `database/0011_current_event_coin_purchases.sql` — idempotent coin purchase ledger.
- `generated/` — exact current generated API/OpenAPI snapshots. The generated files contain other workspace APIs too; the Access endpoints are the `/api/current-events/...` sections.

## Important distinction

“Camera access” in the Old Time camera screen is only the phone permission to take photos and videos. It is unrelated to Access rooms and does not unlock camera filters or charge the user.

## Not included

This snapshot does not add new functionality, alter production code, or include secrets. It also does not claim that the separate LIVE video feature or one-month camera-access gifting feature is part of Access; those are separate product work.
