# Old Time — gifting and financial system source snapshot

This bundle contains the exact current source for Old Time's gifting and creator-finance system at export time. It includes gifts in Access live-audio rooms and Pace route posts, purchased Coins, creator Gold, RevenueCat verification, Stripe Connect payout onboarding, withdrawals, database ledgers, UI screens, generated API contracts, and the current coin/gift artwork.

This is a source snapshot for review and download. It is not a standalone app and it does not change the production workspace. No secrets or credentials are included.

## Money model

Old Time currently has two separate balances:

### Coins

- Coins are the user spending balance.
- Coins are purchased through native App Store / RevenueCat products.
- Coins are used for gifts.
- Coins are not withdrawable and are not creator earnings.
- A new wallet record currently starts with 1,000 Coins when the server first creates it.
- The client displays the planning ratio of 90 Coins = $1 value, but the final purchase price is the store price returned by RevenueCat.
- The server never trusts a client-provided product price or coin amount.

### Gold

- Gold is the creator reward balance earned from gifts.
- The current conversion is `floor(gift Coins × 0.8)` Gold.
- 90 Gold = $1 USD for withdrawals.
- Minimum withdrawal is 900 Gold ($10).
- Withdrawals must be whole-dollar amounts, so the requested Gold must be divisible by 90.
- Gold is withdrawn through a Stripe-connected payout account.
- `pendingGold` exists in the wallet response/model, but the current gift paths credit available `gold` immediately; there is no active pending hold in these routes.

## Current gift catalog

The same six gift types are accepted in Access and Pace:

| Gift | Coins | Gold credited |
|---|---:|---:|
| Coffee | 25 | 20 |
| Idea | 100 | 80 |
| Heart | 200 | 160 |
| Gem | 500 | 400 |
| Studio | 1,000 | 800 |
| Time is up | 10,000 | 8,000 |

The `Time is up` gift includes a full-screen animation in Access. Gifts are charged and credited inside a database transaction.

## Where gifts can be sent

### Access live rooms

- A user must be a participant in the room.
- The recipient must currently be a host, moderator, or speaker in that same room.
- Gifts cannot be sent to an ordinary listener.
- The sender's Coins are debited only if the balance is sufficient.
- The recipient's Gold is credited in the same transaction.
- A persisted gift record is created and a realtime event is broadcast to the room.

### Pace routes

- A user must be authenticated.
- The route must be active and visible to the sender.
- The sender cannot gift their own route.
- The route author receives the Gold.
- The server debits Coins and credits Gold in one transaction, then records the gift.
- The mobile UI explains that Coins thank the route author and the author receives Gold.

## Coin purchase and verification rules

1. The user purchases through the native RevenueCat flow.
2. RevenueCat identifies the user as `oldtime-user-{numericUserId}`.
3. The server asks RevenueCat for the user's verified purchases.
4. Only recognized product identifiers are converted into Coins.
5. Known identifiers include `oldtime_coins_100`, `550`, `1000`, `1200`, `5000`, `10000`, `25000`, `50000`, and `100000` in the full store identifier form.
6. Custom product identifiers are accepted only when the amount is a safe integer from 450 through 900,000 and divisible by 450.
7. Refunded purchases are excluded in the RevenueCat v2 path.
8. Each provider purchase ID is inserted into the coin-purchase ledger with a unique primary key.
9. A purchase that has already been inserted cannot credit the wallet a second time.
10. Wallet crediting and purchase-ledger insertion run in one database transaction.
11. If RevenueCat verification fails, the API returns an unavailable response and tells the client the purchase is safe to retry/restore.

## Payout rules

- Creators use Stripe-hosted onboarding; Old Time does not collect or store bank/card details.
- Old Time stores the connected Stripe account ID and payout status flags.
- Payout setup must have submitted details and payouts enabled before a withdrawal can be requested.
- A withdrawal debits Gold before it creates the payout record, inside a transaction.
- The server creates an idempotent Stripe transfer and payout using the withdrawal ID.
- Stripe transfer and payout IDs are unique when present.
- Failed payouts attempt to reverse the transfer and refund the Gold to the wallet.
- If reversal cannot complete, the withdrawal is marked `reversal_pending` for review.
- Withdrawal history is refreshed against Stripe for non-terminal statuses.
- Current terminal payout statuses are `paid`, `failed`, and `canceled`.
- Withdrawal currency is USD and amounts are positive.

## Anti-abuse and integrity rules encoded today

- All financial endpoints require Old Time authentication.
- Gift type and recipient are validated server-side.
- Client-side prices are never trusted for wallet crediting or gifting.
- Insufficient Coins return an error and do not create a gift.
- Gift debit, Gold credit, and gift record creation are atomic.
- RevenueCat purchase IDs are idempotent.
- Stripe transfer and payout creation use idempotency keys derived from the withdrawal record.
- Stripe redirect return URLs are server-controlled; caller-provided return URLs are not accepted.
- Payout account details remain in Stripe.
- A client cannot withdraw Coins; only creator Gold can be withdrawn.

## Important current limitations

- The system does not yet implement one-month camera-access gifting; that is a separate feature from these current gifts.
- The current UI has a `Transactions` placeholder rather than a complete user-facing transaction ledger.
- Gift prices and the Gold percentage are currently code-level constants, not an admin-configurable catalog.
- The exact store price is controlled by App Store / RevenueCat configuration and can vary by locale.
- Production payout availability depends on valid Stripe configuration and account eligibility.

## File map

### Mobile

- `mobile/wallet.tsx` — Coin balance, Gold balance, recharge, restore, and earnings entry point.
- `mobile/pace.tsx` — Pace route gift picker and send flow.
- `mobile/current-event-room.tsx` — Access room gift picker, recipient selection, coin purchase, and gift animations.
- `mobile/withdraw.tsx` — Gold-to-USD withdrawal validation and history.
- `mobile/payment-settings.tsx` — Stripe-hosted payout setup/status.
- `mobile/revenuecat.tsx` — native purchase, restore, and server wallet synchronization.
- `mobile/pace-api.ts` — Pace gifting request client.
- `mobile/current-event-gifts.ts` — Access gift artwork/catalog.

### Server

- `server/current-events.ts` — Access gifts, wallet, RevenueCat reconciliation, payout onboarding, withdrawal creation/status, and Stripe payout recovery.
- `server/pace.ts` — Pace route gifts and the shared wallet ledger debit/credit transaction.
- `server/revenuecat.ts` — RevenueCat server verification and product-to-Coin mapping.
- `server/stripe-client.ts` — Stripe client creation used by payout code.
- `server/routes-index.ts` — route mounting.
- `server/realtime.ts` and `server/index.ts` — realtime gift events and authenticated Socket.IO handling.

### Database

- `database/current-events.ts` — shared wallet, Access gift, purchase, payout account, and withdrawal tables.
- `database/pace.ts` — Pace route gift table.
- `database/0007_current_events.sql` — initial Access/wallet/gift tables.
- `database/0011_current_event_coin_purchases.sql` — purchase idempotency ledger.
- `database/0016_creator_payouts.sql` — Stripe payout account and withdrawal tables.
- `database/0021_pace_routes_and_gifts.sql` — Pace route gift table.
- `database/0022_pace_route_visibility.sql` and `database/0026_pace_activity_model.sql` — later Pace schema required by the bundled Pace route source.

### Contracts and media

- `generated/` — exact current OpenAPI, generated client, schemas, and Zod snapshots. The relevant endpoints are the `/current-events/wallet`, `/current-events/rooms/{roomId}/gifts`, `/current-events/payouts/*`, and `/pace/routes/{routeId}/gifts` sections.
- `assets/coins/` — wallet/coin artwork.
- `assets/gifts/` — gift artwork and the `Time is up` animation.
