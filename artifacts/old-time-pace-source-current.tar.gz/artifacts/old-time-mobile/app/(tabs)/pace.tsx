import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Location from 'expo-location';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, AppState, FlatList, Keyboard, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import Svg, { Circle, Polyline } from 'react-native-svg';
import { Avatar, Screen } from '@/components/ui';
import { useApp } from '@/context/app-state';
import { useColors } from '@/hooks/useColors';
import { appendTrackedPoint, clearPaceRecording, getStoredPaceRecording, savePaceRecording, startPaceLocationUpdates, stopPaceLocationUpdates, type PaceRecording } from '@/lib/pace-recorder';
import {
  createPaceComment,
  createPaceRoute,
  getPaceComments,
  getPaceFeed,
  getPacePreferences,
  updatePacePreferences,
  sendPaceGift,
  setPaceCommentLike,
  setPaceRouteLike,
  trackPaceSuggestionImpression,
  type PaceActivity,
  type PaceActivityGroup,
  type PaceAudience,
  type PaceComment,
  type PaceDifficulty,
  type PaceExercise,
  type PacePoint,
  type PaceRoute,
  type PaceSuggestion,
} from '@/lib/pace-api';

const GIFT_OPTIONS = [
  { key: 'coffee' as const, label: 'Coffee', price: 25, icon: 'cafe-outline' as const },
  { key: 'idea' as const, label: 'Idea', price: 100, icon: 'bulb-outline' as const },
  { key: 'heart' as const, label: 'Heart', price: 200, icon: 'heart-outline' as const },
  { key: 'gem' as const, label: 'Gem', price: 500, icon: 'diamond-outline' as const },
  { key: 'studio' as const, label: 'Studio', price: 1000, icon: 'albums-outline' as const },
  { key: 'time_is_up' as const, label: 'Time is up', price: 10000, icon: 'trophy-outline' as const },
];

const ACTIVITY_LABELS: Record<PaceActivity, string> = {
  run: 'Run',
  walk: 'Walk',
  bike: 'Ride',
  hike: 'Hike',
  jog: 'Jog',
  swim: 'Swim',
  strength: 'Strength',
  yoga: 'Yoga',
  dance: 'Dance',
  skate: 'Skate',
};
const ACTIVITY_ICONS: Record<PaceActivity, keyof typeof Ionicons.glyphMap> = {
  run: 'footsteps-outline',
  walk: 'walk-outline',
  bike: 'bicycle-outline',
  hike: 'trail-sign-outline',
  jog: 'speedometer-outline',
  swim: 'water-outline',
  strength: 'barbell-outline',
  yoga: 'body-outline',
  dance: 'musical-notes-outline',
  skate: 'fitness-outline',
};
const ACTIVITY_OPTIONS: PaceActivity[] = ['run', 'walk', 'bike', 'hike', 'jog', 'swim', 'strength', 'yoga', 'dance', 'skate'];
const NON_ROUTE_ACTIVITIES: PaceActivity[] = ['strength', 'yoga', 'dance'];
const DIFFICULTY_LABELS: Record<PaceDifficulty, string> = { easy: 'Easy', steady: 'Steady', hard: 'Hard' };
const ACTIVITY_GROUPS: Record<PaceActivity, PaceActivityGroup> = {
  run: 'distance', walk: 'distance', hike: 'distance', jog: 'distance',
  bike: 'ride', skate: 'ride', swim: 'swim', strength: 'strength', yoga: 'studio', dance: 'studio',
};
const ACTIVITY_CALORIES_PER_MINUTE: Record<PaceActivityGroup, number> = { distance: 10, ride: 9, swim: 8, studio: 7, strength: 6 };
const DEFAULT_STRENGTH_EXERCISES: PaceExercise[] = [{ name: 'Squat', sets: 3, reps: 10, weight: null }];

type Coordinate = PacePoint;

function activityGroupFor(activity: PaceActivity): PaceActivityGroup {
  return ACTIVITY_GROUPS[activity];
}

function activityNeedsRoute(activity: PaceActivity) {
  const group = activityGroupFor(activity);
  return group === 'distance' || group === 'ride' || group === 'swim';
}

function activityCalories(activity: PaceActivity, durationMin: number) {
  return Math.max(1, Math.round(durationMin * ACTIVITY_CALORIES_PER_MINUTE[activityGroupFor(activity)]));
}

function activityStats(activity: PaceActivity, distanceKm: number, durationMin: number, calories?: number | null) {
  const group = activityGroupFor(activity);
  if (group === 'ride') return [
    { label: 'DISTANCE', value: `${distanceKm.toFixed(1)} km` },
    { label: 'TIME', value: formatRouteTime(durationMin) },
    { label: 'SPEED', value: `${distanceKm && durationMin ? (distanceKm / (durationMin / 60)).toFixed(1) : '--'} km/h` },
  ];
  if (group === 'swim') {
    const meters = Math.round(distanceKm * 1_000);
    const pacePer100 = meters && durationMin ? Math.round((durationMin * 60 * 100) / meters) : 0;
    return [
      { label: 'METERS', value: `${meters || '--'} m` },
      { label: 'TIME', value: formatRouteTime(durationMin) },
      { label: 'PACE', value: pacePer100 ? `${Math.floor(pacePer100 / 60)}:${String(pacePer100 % 60).padStart(2, '0')} /100 m` : '--' },
    ];
  }
  if (group === 'studio') return [
    { label: 'TIME', value: formatRouteTime(durationMin) },
    { label: 'CALORIES', value: `${calories ?? activityCalories(activity, durationMin)} kcal` },
  ];
  if (group === 'strength') return [
    { label: 'TIME', value: formatRouteTime(durationMin) },
    { label: 'CALORIES', value: `${calories ?? activityCalories(activity, durationMin)} kcal` },
  ];
  return [
    { label: 'DISTANCE', value: `${distanceKm.toFixed(1)} km` },
    { label: 'TIME', value: formatRouteTime(durationMin) },
    { label: 'PACE', value: distanceKm && durationMin ? `${formatRoutePace(distanceKm, durationMin)} /km` : '--' },
  ];
}

function recordingAsSuggestion(recording: PaceRecording): PaceSuggestion {
  const firstPoint = recording.points[0];
  const activity = recording.activity ?? 'run';
  const group = activityGroupFor(activity);
  const routeCoordinates = recording.points.length > 1
    ? recording.points.map(({ latitude, longitude }) => ({ latitude, longitude }))
    : firstPoint
      ? [{ latitude: firstPoint.latitude, longitude: firstPoint.longitude }, { latitude: firstPoint.latitude, longitude: firstPoint.longitude }]
      : [];
  return {
    id: `recorded-${recording.id}`,
    suggested: true,
    title: 'My Pace route',
    description: 'Recorded with Old Time.',
    kind: 'route',
    visibility: 'community',
    audience: 'community',
    activity,
    activityGroup: group,
    difficulty: recording.distanceKm >= 8 ? 'hard' : recording.distanceKm >= 4 ? 'steady' : 'easy',
    distanceKm: recording.distanceKm,
    elevationM: 0,
    durationMin: Math.max(1, Math.round(recording.elapsedSeconds / 60)),
    calories: activityCalories(activity, Math.max(1, Math.round(recording.elapsedSeconds / 60))),
    exerciseLog: recording.exerciseLog ?? [],
    locationLabel: 'Recorded locally',
    distanceFromYouKm: 0,
    routeCoordinates: activityNeedsRoute(activity) ? routeCoordinates : [],
  };
}

export default function PaceScreen() {
  const colors = useColors();
  const { session } = useApp();
  const [permission, requestPermission] = Location.useForegroundPermissions();
  const [location, setLocation] = useState<Coordinate | null>(null);
  const [routes, setRoutes] = useState<PaceRoute[]>([]);
  const [suggestions, setSuggestions] = useState<PaceSuggestion[]>([]);
  const [feedMode, setFeedMode] = useState<'community' | 'for-you'>('community');
  const [defaultAudience, setDefaultAudience] = useState<PaceAudience>('community');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [composer, setComposer] = useState<PaceSuggestion | null>(null);
  const [commentsRoute, setCommentsRoute] = useState<PaceRoute | null>(null);
  const [giftRoute, setGiftRoute] = useState<PaceRoute | null>(null);
  const [recording, setRecording] = useState<PaceRecording | null>(null);
  const [selectedActivity, setSelectedActivity] = useState<PaceActivity>('run');
  const [activityPickerVisible, setActivityPickerVisible] = useState(false);
  const [recordingLoading, setRecordingLoading] = useState(true);
  const [recordingError, setRecordingError] = useState<string | null>(null);
  const [backgroundTrackingEnabled, setBackgroundTrackingEnabled] = useState(false);
  const watchRef = useRef<Location.LocationSubscription | null>(null);
  const impressedSuggestionIdsRef = useRef(new Set<string>());

  const syncRecordingState = useCallback(async () => {
    const stored = await getStoredPaceRecording();
    setRecording(stored);
    if (Platform.OS === 'web') return;
    if (stored?.status === 'recording' && activityNeedsRoute(stored.activity ?? 'run')) {
      try {
        setBackgroundTrackingEnabled(await startPaceLocationUpdates());
      } catch {
        setBackgroundTrackingEnabled(false);
      }
      return;
    }
    setBackgroundTrackingEnabled(false);
    await stopPaceLocationUpdates().catch(() => undefined);
  }, []);

  const load = useCallback(async (showRefresh = false) => {
    if (!session?.authToken) return;
    if (showRefresh) setRefreshing(true);
    else setLoading(true);
    setError(null);
    try {
      const result = await getPaceFeed(session.authToken, location ?? undefined, selectedActivity, [...impressedSuggestionIdsRef.current], feedMode);
      setRoutes(result.items);
      setSuggestions(result.suggestions);
      result.suggestions.forEach((suggestion) => {
        if (impressedSuggestionIdsRef.current.has(suggestion.id)) return;
        impressedSuggestionIdsRef.current.add(suggestion.id);
        void trackPaceSuggestionImpression(session.authToken, suggestion.id, suggestion.activity, location ? `${Math.round(location.latitude * 100)}:${Math.round(location.longitude * 100)}` : 'global').catch(() => {
          impressedSuggestionIdsRef.current.delete(suggestion.id);
        });
      });
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Pace could not load right now.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [feedMode, location, selectedActivity, session?.authToken]);

  useEffect(() => {
    if (!session?.authToken) return;
    void getPacePreferences(session.authToken).then((result) => setDefaultAudience(result.defaultAudience)).catch(() => undefined);
  }, [session?.authToken]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!permission?.granted) return;
    void Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
      .then((result) => setLocation({ latitude: result.coords.latitude, longitude: result.coords.longitude }))
      .catch(() => undefined);
  }, [permission?.granted]);

  useEffect(() => {
    void syncRecordingState()
      .finally(() => setRecordingLoading(false));

    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') {
        void syncRecordingState();
      }
    });
    return () => subscription.remove();
  }, [syncRecordingState]);

  useEffect(() => {
    if (recording?.status !== 'recording' || (Platform.OS !== 'web' && backgroundTrackingEnabled)) {
      watchRef.current?.remove();
      watchRef.current = null;
      if (recording?.status !== 'recording') return;
    }

    if (Platform.OS !== 'web' && backgroundTrackingEnabled) {
      void startPaceLocationUpdates().catch(() => {
        setBackgroundTrackingEnabled(false);
      });
      const interval = setInterval(() => {
        void getStoredPaceRecording().then((stored) => {
          if (stored?.status === 'recording') setRecording(stored);
        });
      }, 2_000);
      return () => clearInterval(interval);
    }

    if (!activityNeedsRoute(recording?.activity ?? 'run')) return;

    let cancelled = false;
    void Location.watchPositionAsync(
      { accuracy: Location.Accuracy.BestForNavigation, distanceInterval: 10, timeInterval: 5_000 },
      (position) => {
        const point = { latitude: position.coords.latitude, longitude: position.coords.longitude, recordedAt: position.timestamp || Date.now() };
        setRecording((current) => {
          if (!current || current.status !== 'recording') return current;
          const updated = appendTrackedPoint(current, point);
          if (updated !== current) void savePaceRecording(updated);
          return updated;
        });
      },
    ).then((subscription) => {
      if (cancelled) subscription.remove();
      else watchRef.current = subscription;
    }).catch(() => undefined);
    return () => {
      cancelled = true;
      watchRef.current?.remove();
      watchRef.current = null;
    };
  }, [backgroundTrackingEnabled, recording?.status]);

  useEffect(() => {
    if (recording?.status !== 'recording') return;
    const interval = setInterval(() => {
      setRecording((current) => {
        if (!current || current.status !== 'recording') return current;
        const updated = { ...current, elapsedSeconds: Math.max(current.elapsedSeconds, Math.floor((Date.now() - current.startedAt) / 1_000)) };
        void savePaceRecording(updated);
        return updated;
      });
    }, 1_000);
    return () => clearInterval(interval);
  }, [recording?.status, recording?.startedAt]);

  async function useLocation() {
    const result = permission?.granted ? permission : await requestPermission();
    if (!result.granted) {
      Alert.alert('Location stays private', 'Allow location access when you want Pace to suggest routes near you. You can still browse the community without it.');
      return;
    }
    try {
      const current = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setLocation({ latitude: current.coords.latitude, longitude: current.coords.longitude });
    } catch {
      Alert.alert('Location unavailable', 'Pace could not read your location. Try again when location services are available.');
    }
  }

  async function startRecording(activityOverride?: PaceActivity) {
    const activity = activityOverride ?? selectedActivity;
    const needsRoute = activityNeedsRoute(activity);
    if (!needsRoute) {
      const now = Date.now();
      const next: PaceRecording = {
        id: `pace-${now}`,
        activity,
        status: 'recording',
        startedAt: now,
        elapsedSeconds: 0,
        distanceKm: 0,
        points: [],
        exerciseLog: activity === 'strength' ? DEFAULT_STRENGTH_EXERCISES : [],
      };
      await savePaceRecording(next);
      setBackgroundTrackingEnabled(false);
      setRecording(next);
      return;
    }
    const result = permission?.granted ? permission : await requestPermission();
    if (!result.granted) {
      const message = Platform.OS === 'web'
        ? 'Allow location access in your browser to record a route here. For reliable GPS tracking, use the Old Time mobile build.'
        : 'Allow location access to record a route. Your route stays on this device until you choose to share it.';
      setRecordingError(message);
      Alert.alert('Location is needed to record', message);
      return;
    }
    try {
      setRecordingError(null);
      let canTrackInBackground = false;
      if (Platform.OS !== 'web') {
        const backgroundPermission = await Location.getBackgroundPermissionsAsync();
        const backgroundResult = backgroundPermission.granted ? backgroundPermission : await Location.requestBackgroundPermissionsAsync();
        canTrackInBackground = backgroundResult.granted;
      }
      const current = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.BestForNavigation });
      const now = Date.now();
      const next: PaceRecording = {
        id: `pace-${now}`,
        activity,
        status: 'recording',
        startedAt: now,
        elapsedSeconds: 0,
        distanceKm: 0,
        points: [{ latitude: current.coords.latitude, longitude: current.coords.longitude, recordedAt: current.timestamp || now }],
      };
      setLocation({ latitude: current.coords.latitude, longitude: current.coords.longitude });
      await savePaceRecording(next);
      setBackgroundTrackingEnabled(canTrackInBackground);
      setRecording(next);
      if (Platform.OS !== 'web' && !canTrackInBackground) {
        Alert.alert('Background tracking is off', 'Pace will keep recording while Old Time is open. Allow background location in Settings to keep recording when your screen is locked.');
      }
    } catch {
      const message = Platform.OS === 'web'
        ? 'The browser could not provide a GPS fix. Allow location access or use the Old Time mobile build for route tracking.'
        : 'Old Time could not get a reliable GPS fix. Try again outside with location services enabled.';
      setRecordingError(message);
      Alert.alert('Could not start tracking', message);
    }
  }

  async function pauseRecording() {
    if (!recording || recording.status !== 'recording') return;
    const paused = { ...recording, status: 'paused' as const, elapsedSeconds: Math.max(recording.elapsedSeconds, Math.floor((Date.now() - recording.startedAt) / 1_000)) };
    await savePaceRecording(paused);
    await stopPaceLocationUpdates().catch(() => undefined);
    setBackgroundTrackingEnabled(false);
    setRecording(paused);
    setRecordingError(null);
  }

  async function resumeRecording() {
    if (!recording || recording.status !== 'paused') return;
    let canTrackInBackground = false;
    if (Platform.OS !== 'web' && activityNeedsRoute(recording.activity ?? 'run')) {
      canTrackInBackground = (await Location.getBackgroundPermissionsAsync()).granted;
    }
    const resumed = { ...recording, status: 'recording' as const, startedAt: Date.now() - recording.elapsedSeconds * 1_000 };
    await savePaceRecording(resumed);
    setRecordingError(null);
    setBackgroundTrackingEnabled(canTrackInBackground);
    setRecording(resumed);
    if (Platform.OS !== 'web' && !canTrackInBackground) {
      Alert.alert('Background tracking is off', 'Pace will keep recording while Old Time is open. Allow background location in Settings to keep recording when your screen is locked.');
    }
  }

  async function finishRecording() {
    if (!recording || recording.status === 'finished') return;
    const finished = { ...recording, status: 'finished' as const, elapsedSeconds: recording.status === 'recording' ? Math.max(recording.elapsedSeconds, Math.floor((Date.now() - recording.startedAt) / 1_000)) : recording.elapsedSeconds };
    await savePaceRecording(finished);
    await stopPaceLocationUpdates().catch(() => undefined);
    setBackgroundTrackingEnabled(false);
    setRecording(finished);
    setRecordingError(null);
    const activity = finished.activity ?? selectedActivity;
    const isStationary = !activityNeedsRoute(activity);
    const needsExercises = activity === 'strength' && !(finished.exerciseLog?.length);
    if ((isStationary && finished.elapsedSeconds < 60) || (activityNeedsRoute(activity) && (finished.points.length < 2 || finished.distanceKm < 0.01)) || needsExercises) {
      Alert.alert(needsExercises ? 'Add an exercise' : isStationary ? 'Session is too short' : 'Route is too short', needsExercises ? 'Add at least one exercise before sharing your Strength session.' : isStationary ? 'Keep the session going for at least one minute so Pace can create a useful summary.' : 'Keep moving a little longer so Pace can create a useful route shape.');
    } else {
      setComposer(recordingAsSuggestion(finished));
    }
  }

  async function discardRecording() {
    if (recording) {
      await savePaceRecording({ ...recording, status: 'paused' });
    }
    await stopPaceLocationUpdates().catch(() => undefined);
    await clearPaceRecording();
    setBackgroundTrackingEnabled(false);
    setRecording(null);
  }

  function updateRoute(updated: PaceRoute) {
    setRoutes((items) => items.map((item) => item.id === updated.id ? updated : item));
  }

  function toggleLike(route: PaceRoute) {
    const liked = !route.viewer.liked;
    updateRoute({ ...route, viewer: { ...route.viewer, liked }, counts: { ...route.counts, likes: Math.max(0, route.counts.likes + (liked ? 1 : -1)) } });
    void setPaceRouteLike(session?.authToken ?? '', route.id, liked).catch(() => updateRoute(route));
  }

  function shareSuggestion(suggestion: PaceSuggestion) {
    setComposer(suggestion);
  }

  return (
    <Screen
      title={
        <View>
          <Text style={[styles.headerEyebrow, { color: colors.primary }]}>OLD TIME</Text>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>Pace</Text>
        </View>
      }
      right={
        <Pressable onPress={() => void useLocation()} style={[styles.headerLocation, { borderColor: colors.border, backgroundColor: colors.card }]} accessibilityRole="button" accessibilityLabel="Use my location">
          <Ionicons name="navigate-outline" size={16} color={location ? colors.primary : colors.mutedForeground} />
          <Text style={[styles.headerLocationText, { color: colors.foreground }]}>{location ? 'Nearby' : 'Set area'}</Text>
        </Pressable>
      }
    >
      <FlatList
        data={routes}
        extraData={{ recording, recordingError, backgroundTrackingEnabled, selectedActivity, feedMode }}
        keyExtractor={(item) => String(item.id)}
        refreshing={refreshing}
        onRefresh={() => void load(true)}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <View>
            <PaceActivityOverview
              colors={colors}
              recording={recording}
              suggestion={suggestions[0]}
               selectedActivity={selectedActivity}
               onStart={() => setActivityPickerVisible(true)}
            />
            <ActivityChooser activity={selectedActivity} colors={colors} onPress={() => setActivityPickerVisible(true)} />
            {!recordingLoading ? <PaceRecorderCard recording={recording} recordingError={recordingError} backgroundTrackingEnabled={backgroundTrackingEnabled} colors={colors} onStart={() => setActivityPickerVisible(true)} onPause={() => void pauseRecording()} onResume={() => void resumeRecording()} onFinish={() => void finishRecording()} onShare={() => recording && setComposer(recordingAsSuggestion(recording))} onDiscard={() => void discardRecording()} onExercisesChange={(exerciseLog) => { if (!recording) return; const updated = { ...recording, exerciseLog }; setRecording(updated); void savePaceRecording(updated); }} /> : null}

            <View style={styles.sectionHeading}>
              <View>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Suggested for you</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>{location ? 'Based on your current area' : 'Global route ideas · nearby is optional'}</Text>
              </View>
              <Ionicons name="shuffle-outline" size={18} color={colors.primary} />
            </View>
            {suggestions.length ? (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.suggestionRow}>
                {suggestions.map((suggestion) => (
                  <SuggestedRouteCard key={suggestion.id} suggestion={suggestion} colors={colors} onShare={() => shareSuggestion(suggestion)} />
                ))}
              </ScrollView>
            ) : (
              <Pressable onPress={() => void useLocation()} style={[styles.locationPrompt, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Ionicons name="location-outline" size={22} color={colors.primary} />
                <View style={styles.flex}>
                  <Text style={[styles.promptTitle, { color: colors.foreground }]}>Make route ideas nearby</Text>
                  <Text style={[styles.promptText, { color: colors.mutedForeground }]}>Global suggestions stay available without location. Use your area only when you want nearby ideas.</Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color={colors.mutedForeground} />
              </Pressable>
            )}

            {routes.length ? <PaceRecentActivities routes={routes.slice(0, 3)} colors={colors} /> : null}

            <View style={styles.feedHeading}>
              <View>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{feedMode === 'community' ? 'Pace community' : 'For you'}</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>{feedMode === 'community' ? 'Every shared Pace activity' : 'Public activities matched to your interests'}</Text>
              </View>
              <Pressable onPress={() => suggestions[0] ? shareSuggestion(suggestions[0]) : void useLocation()} style={[styles.shareButton, { backgroundColor: colors.primary }]} accessibilityRole="button" accessibilityLabel="Share a route">
                <Ionicons name="add" size={17} color={colors.primaryForeground} />
                <Text style={[styles.shareButtonText, { color: colors.primaryForeground }]}>Share</Text>
              </Pressable>
            </View>
            <View style={[styles.feedTabs, { backgroundColor: colors.secondary }]}>
              {(['community', 'for-you'] as const).map((mode) => (
                <Pressable key={mode} onPress={() => setFeedMode(mode)} style={[styles.feedTab, feedMode === mode && { backgroundColor: colors.card }]} accessibilityRole="button" accessibilityState={{ selected: feedMode === mode }}>
                  <Text style={[styles.feedTabText, { color: feedMode === mode ? colors.foreground : colors.mutedForeground }]}>{mode === 'community' ? 'Community' : 'For You'}</Text>
                </Pressable>
              ))}
            </View>
            {loading ? <View style={styles.loading}><ActivityIndicator color={colors.primary} /><Text style={[styles.loadingText, { color: colors.mutedForeground }]}>Finding your pace…</Text></View> : null}
            {error ? <Pressable onPress={() => void load()} style={[styles.errorCard, { backgroundColor: colors.card, borderColor: colors.border }]}><Ionicons name="cloud-offline-outline" size={18} color={colors.destructive} /><Text style={[styles.errorText, { color: colors.foreground }]}>{error} Tap to retry.</Text></Pressable> : null}
          </View>
        }
        ListEmptyComponent={!loading && !error ? <View style={styles.empty}><Ionicons name="map-outline" size={32} color={colors.primary} /><Text style={[styles.emptyTitle, { color: colors.foreground }]}>Be the first out there</Text><Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Share a route or challenge and give the community somewhere new to go.</Text></View> : null}
        renderItem={({ item }) => (
          <PaceRouteCard
            route={item}
            colors={colors}
            onLike={() => toggleLike(item)}
            onComments={() => setCommentsRoute(item)}
            onGift={() => setGiftRoute(item)}
          />
        )}
        ListFooterComponent={<View style={{ height: 26 }} />}
      />
      <RouteComposer
        visible={composer !== null}
        seed={composer}
        colors={colors}
        location={location}
        token={session?.authToken ?? ''}
        defaultAudience={defaultAudience}
        onClose={() => setComposer(null)}
        onDefaultAudienceChange={setDefaultAudience}
        onCreated={async (route) => { await clearPaceRecording(); setRecording(null); setRoutes((items) => [route, ...items]); setComposer(null); }}
      />
      <PaceCommentsSheet
        route={commentsRoute}
        token={session?.authToken ?? ''}
        colors={colors}
        onClose={() => setCommentsRoute(null)}
      />
      <GiftSheet
        route={giftRoute}
        token={session?.authToken ?? ''}
        colors={colors}
        onClose={() => setGiftRoute(null)}
        onSent={(gift) => {
          if (giftRoute) updateRoute({ ...giftRoute, counts: { ...giftRoute.counts, gifts: giftRoute.counts.gifts + 1 } });
          setGiftRoute(null);
        }}
      />
      <ActivityPicker
        visible={activityPickerVisible}
        selectedActivity={selectedActivity}
        colors={colors}
        onClose={() => setActivityPickerVisible(false)}
        onSelect={(activity) => {
          setSelectedActivity(activity);
          setActivityPickerVisible(false);
          void startRecording(activity);
        }}
      />
    </Screen>
  );
}

function formatRoutePace(distanceKm: number, durationMin: number) {
  if (!distanceKm || !durationMin) return '--:--';
  const totalSeconds = Math.round((durationMin * 60) / distanceKm);
  return `${Math.floor(totalSeconds / 60)}:${String(totalSeconds % 60).padStart(2, '0')}`;
}

function formatRouteTime(durationMin: number) {
  if (!durationMin) return '--:--';
  return `${Math.floor(durationMin / 60)}:${String(Math.round(durationMin % 60)).padStart(2, '0')}`;
}

function RouteArtwork({ points, colors }: { points?: PacePoint[]; colors: any }) {
  const routePoints = points?.length && points.length > 1 ? points : [
    { latitude: 0, longitude: 0 },
    { latitude: 0.002, longitude: 0.001 },
    { latitude: 0.001, longitude: 0.004 },
    { latitude: 0.004, longitude: 0.006 },
    { latitude: 0.003, longitude: 0.009 },
    { latitude: 0.006, longitude: 0.011 },
  ];
  const lats = routePoints.map((point) => point.latitude);
  const lngs = routePoints.map((point) => point.longitude);
  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  const minLng = Math.min(...lngs);
  const maxLng = Math.max(...lngs);
  const latSpan = Math.max(maxLat - minLat, 0.0001);
  const lngSpan = Math.max(maxLng - minLng, 0.0001);
  const route = routePoints.map((point) => `${24 + ((point.longitude - minLng) / lngSpan) * 292},${118 - ((point.latitude - minLat) / latSpan) * 94}`).join(' ');
  return (
    <View style={[styles.activityRouteArtwork, { backgroundColor: `${colors.paceInk}E8` }]}>
      <Svg width="100%" height={142} viewBox="0 0 340 142">
        <Polyline points="0,112 64,82 116,92 170,42 236,62 340,20" fill="none" stroke={`${colors.paceCyan}20`} strokeWidth={1} />
        <Polyline points="0,45 68,70 126,28 204,54 280,26 340,48" fill="none" stroke={`${colors.paceCyan}1A`} strokeWidth={1} />
        <Polyline points="12,126 72,105 138,114 186,75 250,94 330,68" fill="none" stroke={`${colors.paceCyan}16`} strokeWidth={1} />
        <Polyline points={route} fill="none" stroke={`${colors.brandOrange}5C`} strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" />
        <Polyline points={route} fill="none" stroke={colors.brandOrange} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" />
      </Svg>
      <View style={[styles.routeStartDot, { backgroundColor: colors.paceCyan }]} />
      <View style={[styles.routeEndDot, { backgroundColor: colors.brandOrange }]} />
    </View>
  );
}

function PaceActivityOverview({ colors, recording, suggestion, selectedActivity, onStart }: { colors: any; recording: PaceRecording | null; suggestion?: PaceSuggestion; selectedActivity: PaceActivity; onStart: () => void }) {
  const distanceKm = recording?.distanceKm ?? suggestion?.distanceKm ?? 0;
  const durationMin = recording ? recording.elapsedSeconds / 60 : suggestion?.durationMin ?? 0;
  const routePoints = recording?.points ?? suggestion?.routeCoordinates;
  const activity = recording?.activity ?? suggestion?.activity ?? selectedActivity;
  const activityLabel = recording ? `${ACTIVITY_LABELS[activity].toUpperCase()} / LIVE` : ACTIVITY_LABELS[activity].toUpperCase();
  const stats = activityStats(activity, distanceKm, durationMin, recording ? activityCalories(activity, durationMin) : suggestion?.calories);
  return (
    <LinearGradient colors={[colors.paceInk, `${colors.brandPurple}E8`]} style={styles.activityOverview}>
      <View style={styles.activityOverviewTop}>
        <View>
          <Text style={styles.activityEyebrow}>PACE / ACTIVITY</Text>
          <Text style={styles.activityTitle}>{activityLabel}</Text>
        </View>
        <View style={styles.activityTopActions}>
          <View style={styles.activityStatus}><Ionicons name="pulse-outline" size={17} color={colors.paceCyan} /><Text style={styles.activityStatusText}>READY</Text></View>
          <Pressable onPress={onStart} style={styles.activityStartButton} accessibilityRole="button" accessibilityLabel="Start a Pace journey">
            <Ionicons name="play" size={14} color={colors.paceInk} />
          </Pressable>
        </View>
      </View>
      {activityNeedsRoute(activity) ? <RouteArtwork points={routePoints} colors={colors} /> : <View style={[styles.activityModeArtwork, { backgroundColor: `${colors.brandPurple}E8` }]}><Ionicons name={ACTIVITY_ICONS[activity]} size={54} color={colors.paceCyan} /><Text style={styles.activityModeArtworkText}>{activityGroupFor(activity) === 'strength' ? 'Log each set as you go.' : 'Time is the measure.'}</Text></View>}
      <View style={styles.activityMetrics}>
        <View style={styles.activityMetric}><Text style={styles.activityMetricLabel}>{stats[0].label}</Text><Text style={styles.activityMetricValue}>{stats[0].value}</Text></View>
        <View style={styles.activityMetricDivider} />
        <View style={styles.activityMetric}><Text style={styles.activityMetricLabel}>{stats[1].label}</Text><Text style={styles.activityMetricValue}>{stats[1].value}</Text></View>
        {stats[2] ? <><View style={styles.activityMetricDivider} /><View style={styles.activityMetric}><Text style={styles.activityMetricLabel}>{stats[2].label}</Text><Text style={styles.activityMetricValue}>{stats[2].value}</Text></View></> : null}
      </View>
      <View style={styles.activityStatRow}>
        <View style={styles.activityStat}><Ionicons name="flame-outline" size={17} color={colors.paceCyan} /><Text style={styles.activityStatLabel}>CALORIES</Text><Text style={styles.activityStatValue}>{recording ? activityCalories(activity, durationMin) : suggestion?.calories ?? activityCalories(activity, durationMin)} kcal</Text></View>
        <View style={styles.activityStat}><Ionicons name="flash-outline" size={17} color={colors.brandOrange} /><Text style={styles.activityStatLabel}>EFFORT</Text><Text style={styles.activityStatValue}>{suggestion ? DIFFICULTY_LABELS[suggestion.difficulty] : 'Open'}</Text></View>
        <View style={styles.activityStat}><Ionicons name={ACTIVITY_ICONS[activity]} size={17} color={colors.paceCyan} /><Text style={styles.activityStatLabel}>ACTIVITY</Text><Text style={styles.activityStatValue}>{ACTIVITY_LABELS[activity]}</Text></View>
      </View>
    </LinearGradient>
  );
}

function ActivityChooser({ activity, colors, onPress }: { activity: PaceActivity; colors: any; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[styles.activityChooser, { backgroundColor: colors.card, borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel={`Choose activity. Current activity is ${ACTIVITY_LABELS[activity]}`}>
      <View style={[styles.activityChooserIcon, { backgroundColor: `${colors.brandOrange}18` }]}><Ionicons name={ACTIVITY_ICONS[activity]} size={18} color={colors.brandOrange} /></View>
      <View style={styles.flex}><Text style={[styles.activityChooserEyebrow, { color: colors.mutedForeground }]}>RECORDING AS</Text><Text style={[styles.activityChooserTitle, { color: colors.foreground }]}>{ACTIVITY_LABELS[activity]}</Text></View>
      <Text style={[styles.activityChooserAction, { color: colors.brandOrange }]}>CHANGE</Text>
      <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
    </Pressable>
  );
}

function ActivityPicker({ visible, selectedActivity, colors, onClose, onSelect }: { visible: boolean; selectedActivity: PaceActivity; colors: any; onClose: () => void; onSelect: (activity: PaceActivity) => void }) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalBackdrop}>
        <View style={[styles.modalCard, { backgroundColor: colors.background }]}>
          <View style={styles.modalHandle} />
          <View style={styles.modalHeader}>
            <View><Text style={[styles.modalEyebrow, { color: colors.primary }]}>SET YOUR PACE</Text><Text style={[styles.modalTitle, { color: colors.foreground }]}>What are you doing?</Text></View>
            <Pressable onPress={onClose} accessibilityLabel="Close activity picker"><Ionicons name="close" size={24} color={colors.mutedForeground} /></Pressable>
          </View>
           <Text style={[styles.activityPickerIntro, { color: colors.mutedForeground }]}>Choose an activity before you start. Pace records a route for distance-based activities and a timed session for studio and Strength activities.</Text>
          <View style={styles.activityGrid}>
            {ACTIVITY_OPTIONS.map((activity) => {
              const selected = activity === selectedActivity;
              return <Pressable key={activity} onPress={() => onSelect(activity)} style={[styles.activityTile, { backgroundColor: selected ? `${colors.brandOrange}18` : colors.card, borderColor: selected ? colors.brandOrange : colors.border }]} accessibilityRole="button" accessibilityState={{ selected }}>
                <View style={[styles.activityTileIcon, { backgroundColor: selected ? colors.brandOrange : `${colors.paceCyan}12` }]}><Ionicons name={ACTIVITY_ICONS[activity]} size={20} color={selected ? colors.primaryForeground : colors.paceCyan} /></View>
                <Text style={[styles.activityTileText, { color: colors.foreground }]}>{ACTIVITY_LABELS[activity]}</Text>
                {selected ? <Ionicons name="checkmark-circle" size={16} color={colors.brandOrange} /> : null}
              </Pressable>;
            })}
          </View>
        </View>
      </View>
    </Modal>
  );
}

function PaceRecentActivities({ routes, colors }: { routes: PaceRoute[]; colors: any }) {
  return (
    <View style={styles.recentActivities}>
      <View style={styles.recentActivitiesHeader}>
        <Text style={[styles.recentActivitiesTitle, { color: colors.foreground }]}>RECENT ACTIVITIES</Text>
        <Text style={[styles.recentActivitiesView, { color: colors.brandOrange }]}>VIEW ALL</Text>
      </View>
      {routes.map((route) => (
        <View key={`recent-${route.id}`} style={[styles.recentActivityRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {activityNeedsRoute(route.activity) ? <RouteThumbnail points={route.routeCoordinates} colors={colors} /> : <View style={[styles.recentActivityIcon, { backgroundColor: colors.secondary }]}><Ionicons name={ACTIVITY_ICONS[route.activity]} size={20} color={colors.primary} /></View>}
          <View style={styles.recentActivityCopy}>
            <Text style={[styles.recentActivityName, { color: colors.foreground }]} numberOfLines={1}>{route.title}</Text>
            <Text style={[styles.recentActivityMeta, { color: colors.mutedForeground }]} numberOfLines={1}>{ACTIVITY_LABELS[route.activity]} · {route.durationMin} min</Text>
          </View>
          <View style={styles.recentActivityMetric}>
            <Text style={[styles.recentActivityDistance, { color: colors.foreground }]}>{activityStats(route.activity, route.distanceKm, route.durationMin, route.calories)[0].value}</Text>
            <Ionicons name="heart" size={14} color={colors.brandOrange} />
          </View>
        </View>
      ))}
    </View>
  );
}

function RouteThumbnail({ points, colors, large = false }: { points: PacePoint[]; colors: any; large?: boolean }) {
  const width = large ? 148 : 86;
  const height = large ? 104 : 76;
  const lats = points.map((point) => point.latitude);
  const lngs = points.map((point) => point.longitude);
  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  const minLng = Math.min(...lngs);
  const maxLng = Math.max(...lngs);
  const latSpan = Math.max(maxLat - minLat, 0.0001);
  const lngSpan = Math.max(maxLng - minLng, 0.0001);
  const coords = points.map((point) => `${12 + ((point.longitude - minLng) / lngSpan) * (width - 24)},${12 + (1 - (point.latitude - minLat) / latSpan) * (height - 24)}`).join(' ');
  const first = coords.split(' ')[0]?.split(',') ?? ['12', '12'];
  const last = coords.split(' ').at(-1)?.split(',') ?? first;
  return (
    <View style={[styles.routeThumbnail, { width, height, backgroundColor: colors.secondary, borderColor: colors.border }]}>
      <Svg width={width} height={height}>
        <Polyline points={coords} fill="none" stroke={`${colors.primary}5C`} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" />
        <Polyline points={coords} fill="none" stroke={colors.primary} strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" />
        <Circle cx={Number(first[0])} cy={Number(first[1])} r={4} fill={colors.foreground} />
        <Circle cx={Number(last[0])} cy={Number(last[1])} r={4} fill={colors.primary} />
      </Svg>
    </View>
  );
}

function SuggestedRouteCard({ suggestion, colors, onShare }: { suggestion: PaceSuggestion; colors: any; onShare: () => void }) {
  return (
    <View style={[styles.suggestionCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
      {activityNeedsRoute(suggestion.activity) ? <RouteThumbnail points={suggestion.routeCoordinates} colors={colors} large /> : <View style={[styles.suggestionModeArtwork, { backgroundColor: colors.secondary }]}><Ionicons name={ACTIVITY_ICONS[suggestion.activity]} size={34} color={colors.primary} /></View>}
      <View style={styles.suggestionBody}>
        <Text style={[styles.suggestionActivity, { color: colors.primary }]}>{ACTIVITY_LABELS[suggestion.activity].toUpperCase()} · {suggestion.locationLabel.toUpperCase()}</Text>
        <Text style={[styles.suggestionTitle, { color: colors.foreground }]} numberOfLines={1}>{suggestion.title}</Text>
        <Text style={[styles.suggestionMeta, { color: colors.mutedForeground }]}>{activityStats(suggestion.activity, suggestion.distanceKm, suggestion.durationMin, suggestion.calories).map((stat) => stat.value).join(' · ')}{suggestion.activityGroup !== 'studio' && suggestion.activityGroup !== 'strength' ? ` · ${DIFFICULTY_LABELS[suggestion.difficulty]}` : ''}</Text>
        <Pressable onPress={onShare} style={[styles.suggestionButton, { backgroundColor: colors.foreground }]} accessibilityRole="button" accessibilityLabel={`Share ${suggestion.title}`}>
          <Ionicons name="arrow-up-outline" size={15} color={colors.background} />
          <Text style={[styles.suggestionButtonText, { color: colors.background }]}>{suggestion.activityGroup === 'strength' || suggestion.activityGroup === 'studio' ? 'Share activity' : 'Share route'}</Text>
        </Pressable>
      </View>
    </View>
  );
}

function PaceRecorderCard({ recording, recordingError, backgroundTrackingEnabled, colors, onStart, onPause, onResume, onFinish, onShare, onDiscard, onExercisesChange }: { recording: PaceRecording | null; recordingError: string | null; backgroundTrackingEnabled: boolean; colors: any; onStart: () => void; onPause: () => void; onResume: () => void; onFinish: () => void; onShare: () => void; onDiscard: () => void; onExercisesChange: (exerciseLog: PaceExercise[]) => void }) {
  const isActive = recording?.status === 'recording';
  const isPaused = recording?.status === 'paused';
  const isFinished = recording?.status === 'finished';
  const isStrength = recording?.activity === 'strength';
  const elapsed = recording?.elapsedSeconds ?? 0;
  const minutes = Math.floor(elapsed / 60);
  const seconds = elapsed % 60;
  return (
    <View style={[styles.recorderCard, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
      <View style={styles.recorderHeader}>
        <View style={[styles.recorderIcon, { backgroundColor: colors.primary }]}><Ionicons name={isActive ? 'radio-outline' : isFinished ? 'checkmark' : 'locate-outline'} size={19} color={colors.primaryForeground} /></View>
        <View style={styles.flex}>
          <Text style={[styles.recorderTitle, { color: colors.foreground }]}>{isFinished ? `${isStrength ? 'Strength session' : 'Route'} ready to share` : isPaused ? `${isStrength ? 'Session' : 'Route'} paused` : isActive ? `${isStrength ? 'Recording your session' : 'Recording your route'}` : `Record ${isStrength ? 'an activity' : 'a route'}`}</Text>
          <Text style={[styles.recorderText, { color: colors.mutedForeground }]}>{isFinished ? 'Review the summary and choose who can see it.' : isStrength ? 'Log each exercise as you go. Your session stays on this device until you choose Share.' : isActive && Platform.OS !== 'web' && backgroundTrackingEnabled ? 'Recording continues if your screen locks. GPS stays on this device until you choose Share.' : 'GPS stays on this device until you choose Share.'}</Text>
        </View>
        {isActive ? <View style={[styles.liveDot, { backgroundColor: colors.destructive }]} /> : null}
      </View>
      {recordingError ? <View style={[styles.recorderError, { backgroundColor: `${colors.destructive}12`, borderColor: `${colors.destructive}45` }]}><Ionicons name="warning-outline" size={16} color={colors.destructive} /><Text style={[styles.recorderErrorText, { color: colors.foreground }]}>{recordingError}</Text></View> : null}
       {recording ? <View style={[styles.recorderStats, { borderTopColor: colors.border }]}>
         {activityStats(recording.activity ?? 'run', recording.distanceKm, elapsed / 60).slice(0, 3).map((stat) => <View key={stat.label}><Text style={[styles.recorderValue, { color: colors.foreground }]}>{stat.value}</Text><Text style={[styles.recorderLabel, { color: colors.mutedForeground }]}>{stat.label.toLowerCase()}</Text></View>)}
      </View> : null}
       {isStrength ? <StrengthExerciseEditor colors={colors} exercises={recording?.exerciseLog ?? []} onChange={onExercisesChange} /> : null}
      <View style={styles.recorderActions}>
        {!recording ? <Pressable onPress={onStart} style={[styles.recorderPrimary, { backgroundColor: colors.foreground }]}><Ionicons name="play" size={15} color={colors.background} /><Text style={[styles.recorderPrimaryText, { color: colors.background }]}>Start tracking</Text></Pressable> : null}
        {isActive ? <><Pressable onPress={onPause} style={[styles.recorderSecondary, { borderColor: colors.border }]}><Ionicons name="pause" size={15} color={colors.foreground} /><Text style={[styles.recorderSecondaryText, { color: colors.foreground }]}>Pause</Text></Pressable><Pressable onPress={onFinish} style={[styles.recorderPrimary, { backgroundColor: colors.foreground }]}><Ionicons name="stop" size={15} color={colors.background} /><Text style={[styles.recorderPrimaryText, { color: colors.background }]}>Finish</Text></Pressable></> : null}
        {isPaused ? <><Pressable onPress={onResume} style={[styles.recorderPrimary, { backgroundColor: colors.foreground }]}><Ionicons name="play" size={15} color={colors.background} /><Text style={[styles.recorderPrimaryText, { color: colors.background }]}>Resume</Text></Pressable><Pressable onPress={onFinish} style={[styles.recorderSecondary, { borderColor: colors.border }]}><Ionicons name="stop" size={15} color={colors.foreground} /><Text style={[styles.recorderSecondaryText, { color: colors.foreground }]}>Finish</Text></Pressable></> : null}
         {isFinished ? <><Pressable onPress={onShare} style={[styles.recorderPrimary, { backgroundColor: colors.primary }]}><Ionicons name="arrow-up-outline" size={15} color={colors.primaryForeground} /><Text style={[styles.recorderPrimaryText, { color: colors.primaryForeground }]}>Share {isStrength ? 'activity' : 'route'}</Text></Pressable><Pressable onPress={onDiscard} style={[styles.recorderSecondary, { borderColor: colors.border }]}><Text style={[styles.recorderSecondaryText, { color: colors.foreground }]}>Discard</Text></Pressable></> : null}
      </View>
    </View>
  );
}

function StrengthExerciseEditor({ colors, exercises, onChange }: { colors: any; exercises: PaceExercise[]; onChange: (exercises: PaceExercise[]) => void }) {
  function update(index: number, patch: Partial<PaceExercise>) {
    onChange(exercises.map((exercise, itemIndex) => itemIndex === index ? { ...exercise, ...patch } : exercise));
  }
  return (
    <View style={styles.exerciseEditor}>
      <View style={styles.exerciseEditorHeader}><Text style={[styles.exerciseEditorTitle, { color: colors.foreground }]}>EXERCISES</Text><Pressable onPress={() => onChange([...exercises, { name: 'New exercise', sets: 3, reps: 10, weight: null }])}><Text style={[styles.exerciseAdd, { color: colors.primary }]}>+ Add</Text></Pressable></View>
      {exercises.map((exercise, index) => <View key={`${index}-${exercise.name}`} style={[styles.exerciseRow, { borderColor: colors.border }]}>
        <TextInput value={exercise.name} onChangeText={(name) => update(index, { name })} placeholder="Exercise name" placeholderTextColor={colors.mutedForeground} style={[styles.exerciseName, { color: colors.foreground }]} />
        <TextInput value={String(exercise.sets)} onChangeText={(value) => update(index, { sets: Math.max(1, Number(value.replace(/\D/g, '')) || 1) })} keyboardType="number-pad" style={[styles.exerciseNumber, { color: colors.foreground, borderColor: colors.border }]} />
        <TextInput value={String(exercise.reps)} onChangeText={(value) => update(index, { reps: Math.max(1, Number(value.replace(/\D/g, '')) || 1) })} keyboardType="number-pad" style={[styles.exerciseNumber, { color: colors.foreground, borderColor: colors.border }]} />
        <TextInput value={exercise.weight == null ? '' : String(exercise.weight)} onChangeText={(value) => update(index, { weight: value ? Number(value) : null })} placeholder="lb" placeholderTextColor={colors.mutedForeground} keyboardType="decimal-pad" style={[styles.exerciseWeight, { color: colors.foreground, borderColor: colors.border }]} />
        <Pressable onPress={() => onChange(exercises.filter((_, itemIndex) => itemIndex !== index))}><Ionicons name="close-circle-outline" size={19} color={colors.mutedForeground} /></Pressable>
      </View>)}
      {!exercises.length ? <Text style={[styles.exerciseEmpty, { color: colors.mutedForeground }]}>Add the exercises you completed.</Text> : null}
      <Text style={[styles.exerciseHint, { color: colors.mutedForeground }]}>Sets · reps · weight</Text>
    </View>
  );
}

function PaceRouteCard({ route, colors, onLike, onComments, onGift }: { route: PaceRoute; colors: any; onLike: () => void; onComments: () => void; onGift: () => void }) {
  return (
    <View style={[styles.routeCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={styles.routeTop}>
        <View style={styles.authorRow}>
          <Avatar name={route.author.name} size={40} uri={route.author.avatarObjectPath ?? undefined} />
          <View style={styles.flex}>
            <Text style={[styles.authorName, { color: colors.foreground }]}>{route.author.name}</Text>
            <Text style={[styles.authorMeta, { color: colors.mutedForeground }]}>@{route.author.username} · {route.locationLabel}</Text>
          </View>
          <View style={[styles.kindPill, { backgroundColor: colors.secondary }]}><Text style={[styles.kindText, { color: colors.primary }]}>{route.kind === 'challenge' ? 'CHALLENGE' : 'ROUTE'}</Text></View>
        </View>
        <Text style={[styles.routeTitle, { color: colors.foreground }]}>{route.title}</Text>
        {route.description ? <Text style={[styles.routeDescription, { color: colors.mutedForeground }]}>{route.description}</Text> : null}
      </View>
      <View style={styles.routeDetailRow}>
        {activityNeedsRoute(route.activity) ? <RouteThumbnail points={route.routeCoordinates} colors={colors} large /> : <View style={[styles.routeModeArtwork, { backgroundColor: colors.secondary }]}><Ionicons name={ACTIVITY_ICONS[route.activity]} size={36} color={colors.primary} /></View>}
        <View style={styles.routeStats}>
          {activityStats(route.activity, route.distanceKm, route.durationMin, route.calories).map((stat) => <Stat key={stat.label} label={stat.label} value={stat.value} colors={colors} />)}
          {route.activityGroup !== 'studio' && route.activityGroup !== 'strength' ? <Stat label="Level" value={DIFFICULTY_LABELS[route.difficulty]} colors={colors} /> : null}
        </View>
      </View>
      {route.activityGroup === 'strength' && route.exerciseLog.length ? <View style={[styles.exerciseSummary, { borderTopColor: colors.border }]}>{route.exerciseLog.map((exercise) => <Text key={`${exercise.name}-${exercise.sets}-${exercise.reps}`} style={[styles.exerciseSummaryText, { color: colors.foreground }]}>{exercise.name} · {exercise.sets} × {exercise.reps}{exercise.weight ? ` · ${exercise.weight} lb` : ''}</Text>)}</View> : null}
      <View style={[styles.routeActions, { borderTopColor: colors.border }]}>
        <Pressable onPress={onLike} style={styles.routeAction} accessibilityRole="button" accessibilityLabel={route.viewer.liked ? 'Unlike route' : 'Like route'}>
          <Ionicons name={route.viewer.liked ? 'heart' : 'heart-outline'} size={19} color={route.viewer.liked ? colors.destructive : colors.mutedForeground} />
          <Text style={[styles.actionCount, { color: colors.mutedForeground }]}>{route.counts.likes}</Text>
        </Pressable>
        <Pressable onPress={onComments} style={styles.routeAction} accessibilityRole="button" accessibilityLabel="Open route comments">
          <Ionicons name="chatbubble-ellipses-outline" size={19} color={colors.mutedForeground} />
          <Text style={[styles.actionCount, { color: colors.mutedForeground }]}>{route.counts.comments}</Text>
        </Pressable>
         {!route.viewer.isOwner ? <Pressable onPress={onGift} style={[styles.giftAction, { backgroundColor: colors.primary }]} accessibilityRole="button" accessibilityLabel={`Send a gift to ${route.author.name}`}>
          <Ionicons name="gift-outline" size={17} color={colors.primaryForeground} />
          <Text style={[styles.giftActionText, { color: colors.primaryForeground }]}>Gift</Text>
          {route.counts.gifts > 0 ? <Text style={[styles.giftCount, { color: colors.primaryForeground }]}>{route.counts.gifts}</Text> : null}
         </Pressable> : <Text style={[styles.ownerLabel, { color: colors.mutedForeground }]}>Your shared activity</Text>}
      </View>
    </View>
  );
}

function Stat({ label, value, colors }: { label: string; value: string; colors: any }) {
  return <View style={styles.stat}><Text style={[styles.statValue, { color: colors.foreground }]}>{value}</Text><Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{label}</Text></View>;
}

function RouteComposer({ visible, seed, colors, location, token, defaultAudience, onClose, onCreated, onDefaultAudienceChange }: { visible: boolean; seed: PaceSuggestion | null; colors: any; location: Coordinate | null; token: string; defaultAudience: PaceAudience; onClose: () => void; onCreated: (route: PaceRoute) => void; onDefaultAudienceChange: (audience: PaceAudience) => void }) {
  const activity = seed?.activity ?? 'run';
  const group = activityGroupFor(activity);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [kind, setKind] = useState<'route' | 'challenge'>('route');
  const [audience, setAudience] = useState<PaceAudience>(defaultAudience);
  const [exercises, setExercises] = useState<PaceExercise[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setTitle(seed?.title ?? '');
    setDescription(seed?.description ?? '');
    setKind(seed?.kind ?? 'route');
    setAudience(seed?.audience ?? defaultAudience);
    setExercises(seed?.exerciseLog ?? (seed?.activity === 'strength' ? DEFAULT_STRENGTH_EXERCISES : []));
  }, [defaultAudience, seed]);

  async function submit() {
    if (activityNeedsRoute(activity) && !seed && !location) {
      Alert.alert('Choose an area first', 'Use your location so Pace can shape a route to share.');
      return;
    }
    const points = seed?.routeCoordinates ?? (location ? [{ ...location }, { latitude: location.latitude + 0.01, longitude: location.longitude + 0.01 }] : []);
    if (!title.trim() || (activityNeedsRoute(activity) && points.length < 2) || (group === 'strength' && !exercises.length)) {
      Alert.alert(group === 'strength' ? 'Add an exercise' : 'Finish your activity', group === 'strength' ? 'Add at least one exercise before sharing.' : 'Add a title and a route shape before sharing.');
      return;
    }
    setSaving(true);
    try {
      const created = await createPaceRoute(token, {
        title: title.trim(),
        description: description.trim(),
        kind,
         audience,
         activity,
         activityGroup: group,
        difficulty: seed?.difficulty ?? 'steady',
         distanceKm: group === 'studio' || group === 'strength' ? 0 : seed?.distanceKm ?? 1,
        elevationM: seed?.elevationM ?? 0,
        durationMin: seed?.durationMin ?? 12,
         calories: seed?.calories ?? activityCalories(activity, seed?.durationMin ?? 12),
         startLatitude: points[0]?.latitude ?? 0,
         startLongitude: points[0]?.longitude ?? 0,
        locationLabel: seed?.locationLabel ?? 'My area',
         routeCoordinates: activityNeedsRoute(activity) ? points : [],
         exerciseLog: exercises,
      });
      onCreated(created);
    } catch (error) {
      Alert.alert('Route not shared', error instanceof Error ? error.message : 'Please try again.');
    } finally {
      setSaving(false);
    }
  }

  return <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
    <KeyboardAvoidingView style={styles.modalBackdrop} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <Pressable style={StyleSheet.absoluteFill} onPress={Keyboard.dismiss} />
      <View style={[styles.modalCard, { backgroundColor: colors.background }]}>
        <View style={styles.modalHandle} />
         <View style={styles.modalHeader}><View><Text style={[styles.modalEyebrow, { color: colors.primary }]}>SHARE TO PACE</Text><Text style={[styles.modalTitle, { color: colors.foreground }]}>{activity === 'strength' ? 'Share your strength session.' : activityNeedsRoute(activity) ? 'Put a route on the map.' : 'Share your activity.'}</Text></View><Pressable onPress={onClose} accessibilityLabel="Close Pace composer"><Ionicons name="close" size={24} color={colors.mutedForeground} /></Pressable></View>
        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.modalContent}>
           <TextInput value={title} onChangeText={setTitle} placeholder={activity === 'strength' ? 'Session name' : 'Route or activity name'} placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.card }]} />
          <TextInput value={description} onChangeText={setDescription} placeholder="What should people know before they go?" placeholderTextColor={colors.mutedForeground} multiline style={[styles.input, styles.multilineInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.card }]} />
          <View style={styles.choiceRow}>
            {(['route', 'challenge'] as const).map((choice) => <Pressable key={choice} onPress={() => setKind(choice)} style={[styles.choice, { borderColor: kind === choice ? colors.primary : colors.border, backgroundColor: kind === choice ? colors.secondary : colors.card }]}><Ionicons name={choice === 'challenge' ? 'trophy-outline' : 'map-outline'} size={17} color={kind === choice ? colors.primary : colors.mutedForeground} /><Text style={[styles.choiceText, { color: kind === choice ? colors.primary : colors.mutedForeground }]}>{choice === 'challenge' ? 'Challenge' : 'Route'}</Text></Pressable>)}
          </View>
           {activity === 'strength' ? <StrengthExerciseEditor colors={colors} exercises={exercises} onChange={setExercises} /> : null}
           <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Who can see this activity?</Text>
          <View style={styles.choiceRow}>
             {(['community', 'public'] as const).map((choice) => <Pressable key={choice} onPress={() => { setAudience(choice); onDefaultAudienceChange(choice); void updatePacePreferences(token, choice).catch(() => undefined); }} style={[styles.choice, { borderColor: audience === choice ? colors.primary : colors.border, backgroundColor: audience === choice ? colors.secondary : colors.card }]}><Ionicons name={choice === 'public' ? 'globe-outline' : 'people-outline'} size={16} color={audience === choice ? colors.primary : colors.mutedForeground} /><Text style={[styles.choiceText, { color: audience === choice ? colors.primary : colors.mutedForeground }]}>{choice === 'public' ? 'Public' : 'Community'}</Text></Pressable>)}
          </View>
           <Text style={[styles.privacyNote, { color: colors.mutedForeground }]}>{audience === 'public' ? 'Public activities can appear in For You. Community activities stay in the Pace community feed.' : 'Community activities are shared with Pace members but are not eligible for For You.'}</Text>
           <View style={[styles.routePreviewLarge, { backgroundColor: colors.card, borderColor: colors.border }]}>{seed ? <>{activityNeedsRoute(activity) ? <RouteThumbnail points={seed.routeCoordinates} colors={colors} large /> : <View style={[styles.previewModeArtwork, { backgroundColor: colors.secondary }]}><Ionicons name={ACTIVITY_ICONS[activity]} size={30} color={colors.primary} /></View>}<View style={styles.previewCopy}><Text style={[styles.previewTitle, { color: colors.foreground }]}>{seed.title}</Text><Text style={[styles.previewMeta, { color: colors.mutedForeground }]}>{activityStats(activity, seed.distanceKm, seed.durationMin, seed.calories).map((stat) => stat.value).join(' · ')}</Text></View></> : <Text style={[styles.previewMeta, { color: colors.mutedForeground }]}>Your recorded activity will be shared with the audience you choose.</Text>}</View>
           <Pressable onPress={() => void submit()} disabled={saving} style={[styles.primaryButton, { backgroundColor: colors.primary, opacity: saving ? 0.6 : 1 }]}><Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>{saving ? 'Sharing…' : `Share ${audience === 'public' ? 'publicly' : 'to the community'}`}</Text></Pressable>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  </Modal>;
}

function PaceCommentsSheet({ route, token, colors, onClose }: { route: PaceRoute | null; token: string; colors: any; onClose: () => void }) {
  const [comments, setComments] = useState<PaceComment[]>([]);
  const [draft, setDraft] = useState('');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (!route) return;
    setLoading(true);
    void getPaceComments(token, route.id).then((result) => setComments(result.items)).catch(() => setComments([])).finally(() => setLoading(false));
  }, [route?.id, token]);

  async function submit() {
    if (!route || !draft.trim() || sending) return;
    setSending(true);
    try {
      const comment = await createPaceComment(token, route.id, draft.trim());
      setComments((items) => [...items, comment]);
      setDraft('');
    } catch (error) {
      Alert.alert('Comment not posted', error instanceof Error ? error.message : 'Please try again.');
    } finally {
      setSending(false);
    }
  }

  return <Modal visible={route !== null} transparent animationType="slide" onRequestClose={onClose}>
    <KeyboardAvoidingView style={styles.modalBackdrop} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.modalCard, { backgroundColor: colors.background, maxHeight: '82%' }]}>
        <View style={styles.modalHandle} />
        <View style={styles.modalHeader}><View><Text style={[styles.modalEyebrow, { color: colors.primary }]}>COMMUNITY</Text><Text style={[styles.modalTitle, { color: colors.foreground }]}>Route notes</Text></View><Pressable onPress={onClose} accessibilityLabel="Close route comments"><Ionicons name="close" size={24} color={colors.mutedForeground} /></Pressable></View>
        {loading ? <ActivityIndicator color={colors.primary} style={{ marginVertical: 28 }} /> : <FlatList data={comments} keyExtractor={(item) => String(item.id)} keyboardShouldPersistTaps="handled" contentContainerStyle={styles.commentsList} ListEmptyComponent={<Text style={[styles.emptyComments, { color: colors.mutedForeground }]}>Be the first to leave a note for this route.</Text>} renderItem={({ item }) => <View style={[styles.commentRow, { borderBottomColor: colors.border }]}><Avatar name={item.author.name} size={32} /><View style={styles.flex}><Text style={[styles.commentAuthor, { color: colors.foreground }]}>{item.author.name} <Text style={{ color: colors.mutedForeground, fontWeight: '400' }}>@{item.author.username}</Text></Text><Text style={[styles.commentContent, { color: colors.foreground }]}>{item.content}</Text><Pressable onPress={() => { const active = !item.liked; setComments((items) => items.map((comment) => comment.id === item.id ? { ...comment, liked: active, likes: Math.max(0, comment.likes + (active ? 1 : -1)) } : comment)); void setPaceCommentLike(token, item.id, active); }} style={styles.commentLike}><Ionicons name={item.liked ? 'heart' : 'heart-outline'} size={14} color={item.liked ? colors.destructive : colors.mutedForeground} /><Text style={[styles.commentLikeText, { color: colors.mutedForeground }]}>{item.likes}</Text></Pressable></View></View>} />}
        <View style={[styles.commentComposer, { borderTopColor: colors.border }]}><TextInput value={draft} onChangeText={setDraft} placeholder="Add a route note…" placeholderTextColor={colors.mutedForeground} style={[styles.commentInput, { color: colors.foreground, backgroundColor: colors.card }]} /><Pressable onPress={() => void submit()} disabled={!draft.trim() || sending} style={[styles.commentSend, { backgroundColor: colors.primary, opacity: !draft.trim() || sending ? 0.5 : 1 }]}><Ionicons name="arrow-up" size={18} color={colors.primaryForeground} /></Pressable></View>
      </View>
    </KeyboardAvoidingView>
  </Modal>;
}

function GiftSheet({ route, token, colors, onClose, onSent }: { route: PaceRoute | null; token: string; colors: any; onClose: () => void; onSent: (gift: string) => void }) {
  const [sending, setSending] = useState<string | null>(null);
  async function send(gift: typeof GIFT_OPTIONS[number]['key']) {
    if (!route) return;
    setSending(gift);
    try {
      await sendPaceGift(token, route.id, gift);
      onSent(gift);
      Alert.alert('Gift sent', `Your ${GIFT_OPTIONS.find((item) => item.key === gift)?.label ?? 'gift'} helped celebrate this route.`);
    } catch (error) {
      Alert.alert('Gift not sent', error instanceof Error ? error.message : 'Check your Coin balance and try again.');
    } finally {
      setSending(null);
    }
  }
  return <Modal visible={route !== null} transparent animationType="slide" onRequestClose={onClose}>
    <View style={styles.modalBackdrop}><View style={[styles.modalCard, { backgroundColor: colors.background }]}>
      <View style={styles.modalHandle} />
      <View style={styles.modalHeader}><View><Text style={[styles.modalEyebrow, { color: colors.primary }]}>CELEBRATE THE EFFORT</Text><Text style={[styles.modalTitle, { color: colors.foreground }]}>Send a gift</Text></View><Pressable onPress={onClose} accessibilityLabel="Close gift picker"><Ionicons name="close" size={24} color={colors.mutedForeground} /></Pressable></View>
      <Text style={[styles.giftIntro, { color: colors.mutedForeground }]}>Use Coins to thank {route?.author.name ?? 'this member'} for sharing a route. They receive Gold.</Text>
      <View style={styles.giftGrid}>{GIFT_OPTIONS.map((item) => <Pressable key={item.key} onPress={() => void send(item.key)} disabled={sending !== null} style={[styles.giftTile, { backgroundColor: colors.card, borderColor: colors.border, opacity: sending && sending !== item.key ? 0.45 : 1 }]}><View style={[styles.giftIcon, { backgroundColor: colors.secondary }]}><Ionicons name={item.icon} size={22} color={colors.primary} /></View><Text style={[styles.giftLabel, { color: colors.foreground }]}>{sending === item.key ? 'Sending…' : item.label}</Text><Text style={[styles.giftPrice, { color: colors.mutedForeground }]}>{item.price.toLocaleString()} Coins</Text></Pressable>)}</View>
    </View></View>
  </Modal>;
}

const styles = StyleSheet.create({
  headerEyebrow: { fontSize: 9, fontWeight: '800', letterSpacing: 1.4 },
  headerTitle: { fontSize: 19, fontWeight: '800', letterSpacing: -0.4, marginTop: 1 },
  headerLocation: { flexDirection: 'row', alignItems: 'center', gap: 5, borderWidth: 1, borderRadius: 18, paddingHorizontal: 10, paddingVertical: 7 },
  headerLocationText: { fontSize: 11, fontWeight: '700' },
  content: { paddingHorizontal: 16, paddingTop: 16, paddingBottom: 110 },
  activityOverview: { borderRadius: 25, padding: 14, overflow: 'hidden', shadowColor: '#000', shadowOpacity: 0.18, shadowRadius: 18, shadowOffset: { width: 0, height: 10 }, elevation: 6 },
  activityOverviewTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 4, paddingBottom: 12 },
  activityEyebrow: { color: '#C8D6E6', fontSize: 10, fontWeight: '900', letterSpacing: 2 },
  activityTitle: { color: '#FFFFFF', fontSize: 24, fontWeight: '800', letterSpacing: -0.6, marginTop: 3 },
  activityTopActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  activityStatus: { flexDirection: 'row', alignItems: 'center', gap: 4, borderWidth: 1, borderColor: 'rgba(54,215,242,0.35)', borderRadius: 14, paddingHorizontal: 8, paddingVertical: 6 },
  activityStatusText: { color: '#C8D6E6', fontSize: 9, fontWeight: '900', letterSpacing: 1 },
  activityStartButton: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FF7800' },
  activityRouteArtwork: { height: 142, borderRadius: 18, overflow: 'hidden', position: 'relative', borderWidth: 1, borderColor: 'rgba(54,215,242,0.18)' },
  activityModeArtwork: { height: 142, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(54,215,242,0.18)', alignItems: 'center', justifyContent: 'center', gap: 9 },
  activityModeArtworkText: { color: '#C8D6E6', fontSize: 12, fontWeight: '700' },
  routeStartDot: { position: 'absolute', left: 18, bottom: 17, width: 9, height: 9, borderRadius: 5, borderWidth: 2, borderColor: '#07131D' },
  routeEndDot: { position: 'absolute', right: 19, top: 16, width: 10, height: 10, borderRadius: 5, borderWidth: 2, borderColor: '#07131D' },
  activityMetrics: { flexDirection: 'row', alignItems: 'center', borderRadius: 17, marginTop: -2, paddingVertical: 12, paddingHorizontal: 7, backgroundColor: 'rgba(7,19,29,0.94)' },
  activityMetric: { flex: 1, paddingHorizontal: 7 },
  activityMetricDivider: { width: StyleSheet.hairlineWidth, height: 38, backgroundColor: 'rgba(200,214,230,0.24)' },
  activityMetricLabel: { color: '#AFC1D2', fontSize: 8, fontWeight: '900', letterSpacing: 1.1 },
  activityMetricValue: { color: '#FFFFFF', fontSize: 19, fontWeight: '800', letterSpacing: -0.5, marginTop: 4 },
  activityMetricUnit: { color: '#C8D6E6', fontSize: 10, fontWeight: '700' },
  activityStatRow: { flexDirection: 'row', gap: 7, marginTop: 9 },
  activityStat: { flex: 1, minHeight: 75, borderRadius: 14, padding: 9, backgroundColor: 'rgba(7,19,29,0.68)', borderWidth: 1, borderColor: 'rgba(200,214,230,0.12)' },
  activityStatLabel: { color: '#AFC1D2', fontSize: 7, fontWeight: '900', letterSpacing: 0.8, marginTop: 7 },
  activityStatValue: { color: '#FFFFFF', fontSize: 13, fontWeight: '800', marginTop: 4 },
  activityChooser: { minHeight: 64, borderRadius: 18, borderWidth: 1, padding: 10, marginTop: 10, flexDirection: 'row', alignItems: 'center', gap: 10 },
  activityChooserIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  activityChooserEyebrow: { fontSize: 8, fontWeight: '900', letterSpacing: 1.2 },
  activityChooserTitle: { fontSize: 14, fontWeight: '800', marginTop: 3 },
  activityChooserAction: { fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  activityPickerIntro: { fontSize: 13, lineHeight: 19, marginTop: 13 },
  activityGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9, marginTop: 18 },
  activityTile: { width: '31.7%', minHeight: 90, borderRadius: 16, borderWidth: 1, padding: 9, justifyContent: 'space-between' },
  activityTileIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  activityTileText: { fontSize: 11, fontWeight: '800', marginTop: 8 },
  hero: { minHeight: 172, borderRadius: 25, padding: 21, flexDirection: 'row', justifyContent: 'space-between', overflow: 'hidden' },
  heroCopy: { flex: 1, paddingRight: 18 },
  heroKicker: { color: '#9FB9FF', fontSize: 10, fontWeight: '800', letterSpacing: 1.8 },
  heroTitle: { color: '#FFFFFF', fontSize: 27, lineHeight: 31, fontWeight: '800', letterSpacing: -0.8, marginTop: 10 },
  heroText: { color: '#CBD5E1', fontSize: 13, lineHeight: 18, marginTop: 9, maxWidth: 260 },
  heroMark: { width: 58, height: 58, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(87,124,255,0.24)' },
  recorderCard: { borderRadius: 20, borderWidth: 1, padding: 14, marginTop: 14 },
  recorderHeader: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  recorderError: { marginTop: 11, padding: 10, borderWidth: 1, borderRadius: 12, flexDirection: 'row', alignItems: 'center', gap: 8 },
  recorderErrorText: { flex: 1, fontSize: 12, lineHeight: 17 },
  recorderIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  recorderTitle: { fontSize: 14, fontWeight: '800' },
  recorderText: { fontSize: 11, lineHeight: 15, marginTop: 3 },
  liveDot: { width: 8, height: 8, borderRadius: 4 },
  recorderStats: { borderTopWidth: StyleSheet.hairlineWidth, marginTop: 13, paddingTop: 12, flexDirection: 'row', justifyContent: 'space-between' },
  recorderValue: { fontSize: 16, fontWeight: '800' },
  recorderLabel: { fontSize: 10, marginTop: 2 },
  recorderActions: { flexDirection: 'row', gap: 8, marginTop: 13 },
  recorderPrimary: { minHeight: 38, borderRadius: 13, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5 },
  recorderPrimaryText: { fontSize: 12, fontWeight: '800' },
  recorderSecondary: { minHeight: 38, borderRadius: 13, borderWidth: 1, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5 },
  recorderSecondaryText: { fontSize: 12, fontWeight: '800' },
  sectionHeading: { marginTop: 26, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { fontSize: 19, fontWeight: '800', letterSpacing: -0.35 },
  sectionSubtitle: { fontSize: 12, marginTop: 4 },
  suggestionRow: { gap: 12, paddingVertical: 14, paddingRight: 12 },
  suggestionCard: { width: 250, minHeight: 268, borderRadius: 21, borderWidth: 1, overflow: 'hidden' },
  suggestionModeArtwork: { height: 104, alignItems: 'center', justifyContent: 'center' },
  suggestionBody: { padding: 13 },
  suggestionActivity: { fontSize: 9, fontWeight: '800', letterSpacing: 1.1 },
  suggestionTitle: { fontSize: 16, fontWeight: '800', marginTop: 5 },
  suggestionMeta: { fontSize: 11, marginTop: 5 },
  suggestionButton: { marginTop: 12, borderRadius: 13, minHeight: 35, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5 },
  suggestionButtonText: { fontSize: 12, fontWeight: '800' },
  routeThumbnail: { overflow: 'hidden', borderWidth: 1, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  locationPrompt: { minHeight: 76, borderRadius: 18, borderWidth: 1, paddingHorizontal: 14, marginTop: 14, flexDirection: 'row', alignItems: 'center', gap: 11 },
  promptTitle: { fontSize: 14, fontWeight: '800' },
  promptText: { fontSize: 11, lineHeight: 15, marginTop: 3 },
  recentActivities: { marginTop: 22 },
  recentActivitiesHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 9 },
  recentActivitiesTitle: { fontSize: 10, fontWeight: '900', letterSpacing: 1.4 },
  recentActivitiesView: { fontSize: 10, fontWeight: '900', letterSpacing: 0.7 },
  recentActivityRow: { minHeight: 74, borderRadius: 16, borderWidth: 1, padding: 8, marginBottom: 8, flexDirection: 'row', alignItems: 'center', gap: 10 },
  recentActivityIcon: { width: 86, height: 76, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  recentActivityCopy: { flex: 1, minWidth: 0 },
  recentActivityName: { fontSize: 13, fontWeight: '800' },
  recentActivityMeta: { fontSize: 10, marginTop: 4 },
  recentActivityMetric: { alignItems: 'flex-end', gap: 7 },
  recentActivityDistance: { fontSize: 12, fontWeight: '800' },
  flex: { flex: 1 },
  feedHeading: { marginTop: 18, marginBottom: 11, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  feedTabs: { flexDirection: 'row', borderRadius: 14, padding: 3, marginBottom: 12 },
  feedTab: { flex: 1, minHeight: 36, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  feedTabText: { fontSize: 12, fontWeight: '800' },
  shareButton: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 11, paddingVertical: 8, borderRadius: 15 },
  shareButtonText: { fontSize: 12, fontWeight: '800' },
  loading: { paddingVertical: 34, alignItems: 'center', gap: 9 },
  loadingText: { fontSize: 13 },
  errorCard: { borderWidth: 1, borderRadius: 16, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 9 },
  errorText: { flex: 1, fontSize: 13, lineHeight: 18 },
  empty: { alignItems: 'center', paddingVertical: 50, paddingHorizontal: 28 },
  emptyTitle: { fontSize: 18, fontWeight: '800', marginTop: 13 },
  emptyText: { textAlign: 'center', fontSize: 13, lineHeight: 19, marginTop: 7 },
  routeCard: { borderRadius: 21, borderWidth: 1, padding: 15, marginBottom: 12 },
  routeTop: {},
  authorRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  authorName: { fontSize: 14, fontWeight: '800' },
  authorMeta: { fontSize: 11, marginTop: 3 },
  kindPill: { borderRadius: 10, paddingHorizontal: 8, paddingVertical: 5 },
  kindText: { fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  routeTitle: { fontSize: 20, fontWeight: '800', letterSpacing: -0.35, marginTop: 17 },
  routeDescription: { fontSize: 13, lineHeight: 18, marginTop: 5 },
  routeDetailRow: { flexDirection: 'row', gap: 14, marginTop: 15 },
  routeModeArtwork: { width: 148, height: 104, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  routeStats: { flex: 1, flexDirection: 'row', flexWrap: 'wrap', alignContent: 'center', rowGap: 13 },
  stat: { width: '50%' },
  statValue: { fontSize: 14, fontWeight: '800' },
  statLabel: { fontSize: 10, marginTop: 2 },
  routeActions: { marginTop: 15, paddingTop: 12, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: 'row', alignItems: 'center', gap: 18 },
  exerciseSummary: { borderTopWidth: StyleSheet.hairlineWidth, marginTop: 13, paddingTop: 10, gap: 4 },
  exerciseSummaryText: { fontSize: 12, fontWeight: '700' },
  routeAction: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  actionCount: { fontSize: 12, fontWeight: '700' },
  giftAction: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 12, marginLeft: 'auto' },
  giftActionText: { fontSize: 12, fontWeight: '800' },
  giftCount: { fontSize: 11, fontWeight: '800', opacity: 0.85 },
  ownerLabel: { marginLeft: 'auto', fontSize: 11, fontWeight: '700' },
  modalBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(7,12,20,0.48)' },
  modalCard: { borderTopLeftRadius: 27, borderTopRightRadius: 27, paddingTop: 10, paddingHorizontal: 18, paddingBottom: 28 },
  modalHandle: { width: 38, height: 4, borderRadius: 2, alignSelf: 'center', backgroundColor: '#AAB3C0', opacity: 0.6, marginBottom: 17 },
  modalHeader: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  modalEyebrow: { fontSize: 9, fontWeight: '900', letterSpacing: 1.5 },
  modalTitle: { fontSize: 22, fontWeight: '800', letterSpacing: -0.45, marginTop: 4 },
  modalContent: { paddingTop: 18, paddingBottom: 8, gap: 12 },
  input: { minHeight: 50, borderRadius: 14, borderWidth: 1, paddingHorizontal: 14, fontSize: 14 },
  multilineInput: { minHeight: 88, paddingTop: 13, textAlignVertical: 'top' },
  choiceRow: { flexDirection: 'row', gap: 9 },
  choice: { flex: 1, minHeight: 44, borderRadius: 13, borderWidth: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 6 },
  choiceText: { fontSize: 12, fontWeight: '800' },
  fieldLabel: { fontSize: 12, fontWeight: '800', marginTop: 2 },
  privacyNote: { fontSize: 11, lineHeight: 15, marginTop: -4 },
  routePreviewLarge: { borderRadius: 17, borderWidth: 1, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 12 },
  previewCopy: { flex: 1 },
  previewModeArtwork: { width: 72, height: 72, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  previewTitle: { fontSize: 14, fontWeight: '800' },
  previewMeta: { fontSize: 11, lineHeight: 16, marginTop: 4 },
  primaryButton: { minHeight: 52, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginTop: 3 },
  primaryButtonText: { fontSize: 14, fontWeight: '800' },
  exerciseEditor: { gap: 8, marginTop: 2, padding: 11, borderRadius: 15, backgroundColor: 'rgba(127,127,127,0.07)' },
  exerciseEditorHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  exerciseEditorTitle: { fontSize: 10, fontWeight: '900', letterSpacing: 1.2 },
  exerciseAdd: { fontSize: 12, fontWeight: '800' },
  exerciseRow: { flexDirection: 'row', alignItems: 'center', gap: 5, borderWidth: 1, borderRadius: 11, padding: 5 },
  exerciseName: { flex: 1, minWidth: 86, fontSize: 12, paddingHorizontal: 5 },
  exerciseNumber: { width: 35, height: 32, borderWidth: 1, borderRadius: 8, textAlign: 'center', fontSize: 12 },
  exerciseWeight: { width: 48, height: 32, borderWidth: 1, borderRadius: 8, textAlign: 'center', fontSize: 12 },
  exerciseEmpty: { fontSize: 12, lineHeight: 17 },
  exerciseHint: { fontSize: 10 },
  commentsList: { paddingTop: 11, paddingBottom: 8 },
  emptyComments: { textAlign: 'center', paddingVertical: 30, fontSize: 13 },
  commentRow: { flexDirection: 'row', gap: 9, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  commentAuthor: { fontSize: 12, fontWeight: '800' },
  commentContent: { fontSize: 13, lineHeight: 18, marginTop: 4 },
  commentLike: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6, alignSelf: 'flex-start' },
  commentLikeText: { fontSize: 11, fontWeight: '700' },
  commentComposer: { borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 11, flexDirection: 'row', gap: 8, alignItems: 'center' },
  commentInput: { flex: 1, minHeight: 43, borderRadius: 15, paddingHorizontal: 13, fontSize: 13 },
  commentSend: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  giftIntro: { fontSize: 13, lineHeight: 19, marginTop: 13, marginBottom: 16 },
  giftGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  giftTile: { width: '31.8%', minHeight: 104, borderRadius: 16, borderWidth: 1, alignItems: 'center', justifyContent: 'center', padding: 8 },
  giftIcon: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  giftLabel: { fontSize: 11, fontWeight: '800', marginTop: 6 },
  giftPrice: { fontSize: 9, marginTop: 3 },
});