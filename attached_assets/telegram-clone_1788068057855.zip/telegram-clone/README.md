# Telegram Clone (React Native / Expo)

A real, working chat app with Telegram-style UI, backed by a **live Supabase project**
that was created for you as part of this build:

- Project ref: `tyyfyxmdxvloekrkfjmt`
- URL: `https://tyyfyxmdxvloekrkfjmt.supabase.co`
- Dashboard: https://supabase.com/dashboard/project/tyyfyxmdxvloekrkfjmt

The Supabase URL and anon key are already wired into `src/lib/supabase.js` — no setup
needed there. Auth, database, and realtime messaging are fully live right now.

## What's implemented
- Email/password signup & login (Supabase Auth)
- Auto-created user profile on signup (via DB trigger)
- Search users by username, start a 1:1 chat
- Realtime messaging (Postgres changes via Supabase Realtime) — two phones/simulators
  running the app can message each other live
- Chat list with last message preview
- Profile screen with editable status + logout
- Telegram-style UI: blue gradient header, message bubbles (green-out / white-in),
  rounded avatars with colored initials, paper-plane app icon (`src/assets/icon.png`)
- Row Level Security on every table — users only see chats/messages they're a member of

## What's NOT implemented (would need significant extra work)
- Voice/video calls
- Media (photos, files, stickers, voice notes) — currently text-only
- Group chat creation UI (schema supports groups; only 1:1 creation UI is built)
- Push notifications
- End-to-end encryption (Telegram's "Secret Chats") — messages are encrypted in transit
  and at rest by Supabase, but not E2E encrypted between users
- Message editing/deleting UI (columns exist in DB, no UI wired up)

## Running it

```bash
npm install
npx expo start
```

Then:
- Press `i` for iOS simulator, `a` for Android emulator, or scan the QR code with the
  **Expo Go** app on your phone.
- To test real multi-user chat, run the app on two devices/simulators, sign up two
  different accounts, and message between them — messages appear instantly on both.

## Requirements
- Node.js 18+
- Expo CLI (`npx expo` — no global install needed)
- Xcode (for iOS simulator) or Android Studio (for Android emulator), or just the
  Expo Go app on a physical phone

## Project structure
```
App.js                      Navigation + auth state
src/lib/supabase.js         Supabase client (URL + key already filled in)
src/theme/colors.js         Telegram-style color palette
src/screens/AuthScreen.js   Login / signup
src/screens/ChatListScreen.js
src/screens/ChatScreen.js   Realtime message thread
src/screens/NewChatScreen.js  User search + start chat
src/screens/ProfileScreen.js
src/components/Avatar.js
src/assets/icon.png         Original paper-plane icon (not Telegram's trademarked logo)
```

## Database schema
Tables: `profiles`, `chats`, `chat_members`, `messages` — all with RLS policies
restricting access to chat members only. Full SQL is in the Supabase project's
migration history if you want to review or extend it.

## Note on the icon
I generated an original blue-circle paper-plane icon in the same visual spirit as
Telegram's, rather than copying Telegram's actual trademarked logo.
