import React, { useEffect, useState } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { supabase } from "../lib/supabase";
import { colors } from "../theme/colors";
import Avatar from "../components/Avatar";

export default function ProfileScreen() {
  const [profile, setProfile] = useState(null);
  const [status, setStatus] = useState("");

  useEffect(() => {
    (async () => {
      const { data: userData } = await supabase.auth.getUser();
      const { data } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", userData.user.id)
        .single();
      setProfile(data);
      setStatus(data?.status || "");
    })();
  }, []);

  const saveStatus = async () => {
    if (!profile) return;
    await supabase.from("profiles").update({ status }).eq("id", profile.id);
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={[colors.accentGradientStart, colors.accentGradientEnd]}
        style={styles.header}
      >
        {profile && <Avatar name={profile.display_name} size={90} />}
        <Text style={styles.name}>{profile?.display_name}</Text>
        <Text style={styles.username}>@{profile?.username}</Text>
      </LinearGradient>

      <View style={styles.section}>
        <Text style={styles.label}>Status</Text>
        <TextInput
          style={styles.input}
          value={status}
          onChangeText={setStatus}
          onBlur={saveStatus}
          placeholder="Say something about yourself"
        />
      </View>

      <TouchableOpacity style={styles.logoutBtn} onPress={() => supabase.auth.signOut()}>
        <Text style={styles.logoutText}>Log Out</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { alignItems: "center", paddingVertical: 32 },
  name: { fontSize: 22, fontWeight: "700", color: "#fff", marginTop: 12 },
  username: { fontSize: 14, color: "rgba(255,255,255,0.85)", marginTop: 4 },
  section: { padding: 16, backgroundColor: colors.headerBg, marginTop: 16 },
  label: { fontSize: 13, color: colors.textSecondary, marginBottom: 6 },
  input: {
    fontSize: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    paddingVertical: 6
  },
  logoutBtn: { margin: 24, alignItems: "center" },
  logoutText: { color: "#EE5253", fontSize: 16, fontWeight: "600" }
});
