import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  RefreshControl
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { supabase } from "../lib/supabase";
import { colors } from "../theme/colors";
import Avatar from "../components/Avatar";

export default function ChatListScreen({ navigation }) {
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [me, setMe] = useState(null);

  const loadChats = useCallback(async () => {
    const { data: userData } = await supabase.auth.getUser();
    const user = userData?.user;
    if (!user) return;
    setMe(user);

    // Get chat ids I'm a member of
    const { data: memberships } = await supabase
      .from("chat_members")
      .select("chat_id")
      .eq("user_id", user.id);

    const chatIds = (memberships || []).map((m) => m.chat_id);
    if (chatIds.length === 0) {
      setChats([]);
      setLoading(false);
      return;
    }

    const { data: chatRows } = await supabase
      .from("chats")
      .select("id, is_group, title, chat_members(user_id, profiles(id, display_name, username))")
      .in("id", chatIds);

    // Get last message per chat
    const enriched = await Promise.all(
      (chatRows || []).map(async (chat) => {
        const { data: lastMsg } = await supabase
          .from("messages")
          .select("content, created_at, sender_id")
          .eq("chat_id", chat.id)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();

        const otherMember = chat.chat_members?.find((m) => m.user_id !== user.id);
        const title = chat.is_group
          ? chat.title || "Group Chat"
          : otherMember?.profiles?.display_name || "Unknown";

        return {
          id: chat.id,
          title,
          lastMessage: lastMsg?.content || "No messages yet",
          lastAt: lastMsg?.created_at,
          otherUserId: otherMember?.profiles?.id
        };
      })
    );

    enriched.sort((a, b) => new Date(b.lastAt || 0) - new Date(a.lastAt || 0));
    setChats(enriched);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadChats();
    const unsub = navigation.addListener("focus", loadChats);

    const channel = supabase
      .channel("messages-list-updates")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages" },
        () => loadChats()
      )
      .subscribe();

    return () => {
      unsub();
      supabase.removeChannel(channel);
    };
  }, [loadChats, navigation]);

  const timeAgo = (iso) => {
    if (!iso) return "";
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Chats</Text>
        <View style={styles.headerIcons}>
          <TouchableOpacity onPress={() => navigation.navigate("NewChat")}>
            <Text style={styles.headerIcon}>✏️</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate("Profile")}>
            <Text style={styles.headerIcon}>👤</Text>
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        data={chats}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl refreshing={loading} onRefresh={loadChats} />
        }
        ListEmptyComponent={
          !loading && (
            <View style={styles.empty}>
              <Text style={styles.emptyText}>No chats yet.</Text>
              <Text style={styles.emptySubtext}>
                Tap ✏️ to start a new conversation.
              </Text>
            </View>
          )
        }
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.row}
            onPress={() =>
              navigation.navigate("Chat", { chatId: item.id, title: item.title })
            }
          >
            <Avatar name={item.title} />
            <View style={styles.rowText}>
              <View style={styles.rowTop}>
                <Text style={styles.rowTitle} numberOfLines={1}>
                  {item.title}
                </Text>
                <Text style={styles.rowTime}>{timeAgo(item.lastAt)}</Text>
              </View>
              <Text style={styles.rowMessage} numberOfLines={1}>
                {item.lastMessage}
              </Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.headerBg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border
  },
  headerTitle: { fontSize: 28, fontWeight: "700", color: colors.textPrimary },
  headerIcons: { flexDirection: "row", gap: 16 },
  headerIcon: { fontSize: 22, marginLeft: 16 },
  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.headerBg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border
  },
  rowText: { flex: 1, marginLeft: 12 },
  rowTop: { flexDirection: "row", justifyContent: "space-between" },
  rowTitle: { fontSize: 16, fontWeight: "600", color: colors.textPrimary, flex: 1 },
  rowTime: { fontSize: 12, color: colors.textSecondary },
  rowMessage: { fontSize: 14, color: colors.textSecondary, marginTop: 2 },
  empty: { alignItems: "center", marginTop: 100 },
  emptyText: { fontSize: 16, color: colors.textSecondary },
  emptySubtext: { fontSize: 13, color: colors.textSecondary, marginTop: 4 }
});
