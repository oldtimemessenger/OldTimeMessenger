import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  StyleSheet
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { supabase } from "../lib/supabase";
import { colors } from "../theme/colors";
import Avatar from "../components/Avatar";

export default function NewChatScreen({ navigation }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);

  const search = async (q) => {
    setQuery(q);
    if (q.trim().length < 2) {
      setResults([]);
      return;
    }
    const { data: userData } = await supabase.auth.getUser();
    const { data } = await supabase
      .from("profiles")
      .select("id, username, display_name")
      .ilike("username", `%${q.trim()}%`)
      .neq("id", userData.user.id)
      .limit(20);
    setResults(data || []);
  };

  const startChat = async (otherUser) => {
    const { data: userData } = await supabase.auth.getUser();
    const me = userData.user;

    // Check for existing 1:1 chat between these two users
    const { data: myChats } = await supabase
      .from("chat_members")
      .select("chat_id")
      .eq("user_id", me.id);

    for (const mc of myChats || []) {
      const { data: members } = await supabase
        .from("chat_members")
        .select("user_id")
        .eq("chat_id", mc.chat_id);
      const ids = (members || []).map((m) => m.user_id).sort();
      if (ids.length === 2 && ids.includes(otherUser.id) && ids.includes(me.id)) {
        navigation.replace("Chat", { chatId: mc.chat_id, title: otherUser.display_name });
        return;
      }
    }

    // Create new chat
    const { data: chat, error } = await supabase
      .from("chats")
      .insert({ is_group: false, created_by: me.id })
      .select()
      .single();
    if (error) return;

    await supabase.from("chat_members").insert([
      { chat_id: chat.id, user_id: me.id },
      { chat_id: chat.id, user_id: otherUser.id }
    ]);

    navigation.replace("Chat", { chatId: chat.id, title: otherUser.display_name });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.searchBar}>
        <TextInput
          style={styles.input}
          placeholder="Search by username"
          value={query}
          onChangeText={search}
          autoCapitalize="none"
          autoFocus
        />
      </View>
      <FlatList
        data={results}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.row} onPress={() => startChat(item)}>
            <Avatar name={item.display_name} />
            <View style={{ marginLeft: 12 }}>
              <Text style={styles.name}>{item.display_name}</Text>
              <Text style={styles.username}>@{item.username}</Text>
            </View>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          query.length >= 2 && (
            <Text style={styles.empty}>No users found.</Text>
          )
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  searchBar: { padding: 12, backgroundColor: colors.headerBg },
  input: {
    backgroundColor: colors.background,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 16
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.headerBg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border
  },
  name: { fontSize: 16, fontWeight: "600", color: colors.textPrimary },
  username: { fontSize: 13, color: colors.textSecondary },
  empty: { textAlign: "center", marginTop: 40, color: colors.textSecondary }
});
