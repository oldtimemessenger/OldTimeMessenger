import React, { useEffect, useState, useRef, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { supabase } from "../lib/supabase";
import { colors } from "../theme/colors";

export default function ChatScreen({ route, navigation }) {
  const { chatId, title } = route.params;
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [myId, setMyId] = useState(null);
  const listRef = useRef(null);

  useEffect(() => {
    navigation.setOptions({ title });
  }, [title, navigation]);

  const loadMessages = useCallback(async () => {
    const { data: userData } = await supabase.auth.getUser();
    setMyId(userData?.user?.id);

    const { data } = await supabase
      .from("messages")
      .select("id, content, created_at, sender_id, profiles(display_name)")
      .eq("chat_id", chatId)
      .order("created_at", { ascending: true });

    setMessages(data || []);
  }, [chatId]);

  useEffect(() => {
    loadMessages();

    const channel = supabase
      .channel(`chat-${chatId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages", filter: `chat_id=eq.${chatId}` },
        (payload) => {
          setMessages((prev) => [...prev, payload.new]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [chatId, loadMessages]);

  const sendMessage = async () => {
    const content = text.trim();
    if (!content) return;
    setText("");
    const { data: userData } = await supabase.auth.getUser();
    const user = userData?.user;
    if (!user) return;

    await supabase.from("messages").insert({
      chat_id: chatId,
      sender_id: user.id,
      content
    });
  };

  const formatTime = (iso) =>
    new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  return (
    <SafeAreaView style={styles.container} edges={["bottom"]}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={90}
      >
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
          renderItem={({ item }) => {
            const mine = item.sender_id === myId;
            return (
              <View
                style={[
                  styles.bubbleWrap,
                  mine ? styles.bubbleWrapOut : styles.bubbleWrapIn
                ]}
              >
                <View style={[styles.bubble, mine ? styles.bubbleOut : styles.bubbleIn]}>
                  <Text style={mine ? styles.bubbleTextOut : styles.bubbleTextIn}>
                    {item.content}
                  </Text>
                  <Text style={styles.bubbleTime}>{formatTime(item.created_at)}</Text>
                </View>
              </View>
            );
          }}
        />

        <View style={styles.inputBar}>
          <TextInput
            style={styles.input}
            placeholder="Message"
            value={text}
            onChangeText={setText}
            multiline
          />
          <TouchableOpacity style={styles.sendBtn} onPress={sendMessage}>
            <Text style={styles.sendIcon}>➤</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.chatBackground },
  list: { paddingHorizontal: 10, paddingVertical: 12 },
  bubbleWrap: { marginBottom: 6, flexDirection: "row" },
  bubbleWrapOut: { justifyContent: "flex-end" },
  bubbleWrapIn: { justifyContent: "flex-start" },
  bubble: {
    maxWidth: "78%",
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 8
  },
  bubbleOut: { backgroundColor: colors.bubbleOut, borderTopRightRadius: 4 },
  bubbleIn: {
    backgroundColor: colors.bubbleIn,
    borderTopLeftRadius: 4,
    borderWidth: 1,
    borderColor: colors.border
  },
  bubbleTextOut: { color: colors.bubbleOutText, fontSize: 16 },
  bubbleTextIn: { color: colors.bubbleInText, fontSize: 16 },
  bubbleTime: {
    fontSize: 10,
    color: colors.textSecondary,
    alignSelf: "flex-end",
    marginTop: 4
  },
  inputBar: {
    flexDirection: "row",
    alignItems: "flex-end",
    padding: 8,
    backgroundColor: colors.headerBg,
    borderTopWidth: 1,
    borderTopColor: colors.border
  },
  input: {
    flex: 1,
    backgroundColor: colors.background,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 16,
    maxHeight: 100,
    marginRight: 8
  },
  sendBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary,
    alignItems: "center",
    justifyContent: "center"
  },
  sendIcon: { color: "#fff", fontSize: 18 }
});
