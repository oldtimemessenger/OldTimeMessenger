export const colors = {
  primary: "#54A9EB",
  primaryDark: "#3B8FD6",
  accentGradientStart: "#63BFFB",
  accentGradientEnd: "#3B8FD6",
  bubbleOut: "#EEFFDE",
  bubbleOutText: "#1B1B1B",
  bubbleIn: "#FFFFFF",
  bubbleInText: "#1B1B1B",
  background: "#EFEFF4",
  chatBackground: "#E6EBEE",
  headerBg: "#FFFFFF",
  border: "#E1E1E5",
  textPrimary: "#1B1B1B",
  textSecondary: "#8E8E93",
  online: "#4DC24B",
  unreadBadge: "#54A9EB",
  white: "#FFFFFF",
  avatarPalette: [
    "#FF9F43",
    "#EE5253",
    "#54A9EB",
    "#10AC84",
    "#8E44AD",
    "#FF6B81",
    "#2E86DE",
    "#F7B731"
  ]
};
