import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { BlurView } from 'expo-blur'; // if not using Expo, swap for a plain semi-opaque overlay

/**
 * SubscriptionGate
 * -------------------------------------------------
 * Wraps subscriber-only content. If the viewer isn't subscribed,
 * it blurs the content and shows a "Subscribe to unlock" CTA
 * instead of hiding the post entirely — this is what drives
 * conversion (people see *that* something exists, not just a gap).
 */
export default function SubscriptionGate({
  isSubscribed,
  price,
  creatorName,
  onSubscribe,
  children,
}) {
  const [subscribing, setSubscribing] = React.useState(false);

  if (isSubscribed) {
    return children;
  }

  const handleSubscribe = async () => {
    setSubscribing(true);
    try {
      await onSubscribe();
    } finally {
      setSubscribing(false);
    }
  };

  return (
    <View style={styles.wrapper}>
      <View style={styles.blurredContent} pointerEvents="none">
        {children}
      </View>
      <BlurView intensity={35} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={styles.overlay}>
        <Text style={styles.lockIcon}>🔒</Text>
        <Text style={styles.title}>Subscriber-only content</Text>
        <Text style={styles.subtitle}>
          Subscribe to {creatorName} for ${price}/mo to unlock this and more.
        </Text>
        <TouchableOpacity
          style={styles.cta}
          onPress={handleSubscribe}
          disabled={subscribing}
          activeOpacity={0.85}
        >
          {subscribing ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <Text style={styles.ctaText}>Subscribe · ${price}/mo</Text>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    borderRadius: 14,
    overflow: 'hidden',
    minHeight: 120,
  },
  blurredContent: {
    opacity: 0.5,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  lockIcon: {
    fontSize: 22,
    marginBottom: 6,
  },
  title: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 15,
    marginBottom: 4,
    textAlign: 'center',
  },
  subtitle: {
    color: '#e8e8e8',
    fontSize: 12.5,
    textAlign: 'center',
    marginBottom: 12,
    lineHeight: 17,
  },
  cta: {
    backgroundColor: '#6C4EF5',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 24,
    minWidth: 150,
    alignItems: 'center',
  },
  ctaText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 13.5,
  },
});
