import React, { createContext, useContext, useState, useCallback } from 'react';

/**
 * UpdatesContext
 * -------------------------------------------------
 * Central state for the "Updates" feed. This ships with an in-memory
 * mock data layer so the UI is fully functional out of the box.
 * Swap `mockApi` calls for real fetch()/API calls to your backend
 * when you're ready — every function returns a Promise already,
 * so the swap is drop-in.
 */

const UpdatesContext = createContext(null);

// ---- Mock data ----
let idCounter = 100;
const now = Date.now();

const seedPosts = [
  {
    id: '1',
    authorId: 'u1',
    authorName: 'Maya Chen',
    authorAvatar: 'https://i.pravatar.cc/150?u=u1',
    isCreator: true,
    subscriberOnly: false,
    text: 'Just dropped a new behind-the-scenes video 🔥',
    mediaUrl: null,
    createdAt: now - 1000 * 60 * 5,
    reactions: { '❤️': 42, '🔥': 18 },
    myReaction: null,
    commentCount: 6,
    expiresAt: now + 1000 * 60 * 60 * 19, // ~24h disappearing window
  },
  {
    id: '2',
    authorId: 'u2',
    authorName: 'DJ Rico',
    authorAvatar: 'https://i.pravatar.cc/150?u=u2',
    isCreator: true,
    subscriberOnly: true,
    text: 'Subscriber-only: tracklist for Friday\'s set is up.',
    mediaUrl: null,
    createdAt: now - 1000 * 60 * 40,
    reactions: { '❤️': 9 },
    myReaction: null,
    commentCount: 2,
    expiresAt: now + 1000 * 60 * 60 * 22,
  },
  {
    id: '3',
    authorId: 'me',
    authorName: 'You',
    authorAvatar: 'https://i.pravatar.cc/150?u=me',
    isCreator: false,
    subscriberOnly: false,
    text: 'Coffee, sunrise, good day ahead ☀️',
    mediaUrl: null,
    createdAt: now - 1000 * 60 * 90,
    reactions: {},
    myReaction: null,
    commentCount: 0,
    expiresAt: now + 1000 * 60 * 60 * 22.5,
  },
];

// Tracks which creators the current user is subscribed to (mock)
const seedSubscriptions = new Set(['u1']);

// Simple engagement counters that drive the creator-upgrade prompts
const seedEngagement = {
  followers: 118,
  lastPostViews: 5200,
  totalReactionsReceived: 340,
  liveRoomsJoined: 7,
};

const mockApi = {
  async fetchFeed() {
    await delay(300);
    return seedPosts.filter((p) => p.expiresAt > Date.now());
  },
  async createPost({ text, subscriberOnly }) {
    await delay(250);
    const post = {
      id: String(idCounter++),
      authorId: 'me',
      authorName: 'You',
      authorAvatar: 'https://i.pravatar.cc/150?u=me',
      isCreator: false,
      subscriberOnly: !!subscriberOnly,
      text,
      mediaUrl: null,
      createdAt: Date.now(),
      reactions: {},
      myReaction: null,
      commentCount: 0,
      expiresAt: Date.now() + 1000 * 60 * 60 * 24,
    };
    seedPosts.unshift(post);
    return post;
  },
  async toggleReaction(postId, emoji) {
    await delay(120);
    const post = seedPosts.find((p) => p.id === postId);
    if (!post) return null;
    if (post.myReaction === emoji) {
      post.reactions[emoji] = Math.max(0, (post.reactions[emoji] || 1) - 1);
      post.myReaction = null;
    } else {
      if (post.myReaction) {
        post.reactions[post.myReaction] = Math.max(0, (post.reactions[post.myReaction] || 1) - 1);
      }
      post.reactions[emoji] = (post.reactions[emoji] || 0) + 1;
      post.myReaction = emoji;
    }
    return { ...post };
  },
  async isSubscribedTo(creatorId) {
    await delay(80);
    return seedSubscriptions.has(creatorId);
  },
  async subscribeTo(creatorId) {
    await delay(300);
    seedSubscriptions.add(creatorId);
    return true;
  },
  async fetchEngagement() {
    await delay(100);
    return { ...seedEngagement };
  },
};

function delay(ms) {
  return new Promise((res) => setTimeout(res, ms));
}

// ---- Provider ----
export function UpdatesProvider({ children }) {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [subscriptions, setSubscriptions] = useState(new Set(['u1']));
  const [engagement, setEngagement] = useState(null);

  const loadFeed = useCallback(async () => {
    setLoading(true);
    const feed = await mockApi.fetchFeed();
    setPosts(feed);
    const eng = await mockApi.fetchEngagement();
    setEngagement(eng);
    setLoading(false);
  }, []);

  const addPost = useCallback(async (text, subscriberOnly) => {
    const post = await mockApi.createPost({ text, subscriberOnly });
    setPosts((prev) => [post, ...prev]);
    return post;
  }, []);

  const react = useCallback(async (postId, emoji) => {
    const updated = await mockApi.toggleReaction(postId, emoji);
    if (updated) {
      setPosts((prev) => prev.map((p) => (p.id === postId ? updated : p)));
    }
  }, []);

  const subscribeTo = useCallback(async (creatorId) => {
    await mockApi.subscribeTo(creatorId);
    setSubscriptions((prev) => new Set(prev).add(creatorId));
  }, []);

  const isSubscribed = useCallback(
    (creatorId) => subscriptions.has(creatorId),
    [subscriptions]
  );

  const value = {
    posts,
    loading,
    loadFeed,
    addPost,
    react,
    subscribeTo,
    isSubscribed,
    engagement,
  };

  return <UpdatesContext.Provider value={value}>{children}</UpdatesContext.Provider>;
}

export function useUpdates() {
  const ctx = useContext(UpdatesContext);
  if (!ctx) throw new Error('useUpdates must be used within an UpdatesProvider');
  return ctx;
}
