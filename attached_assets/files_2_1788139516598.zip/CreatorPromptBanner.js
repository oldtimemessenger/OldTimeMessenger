import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

/**
 * CreatorPromptBanner
 * -------------------------------------------------
 * Picks the single most relevant contextual nudge based on the
 * user's engagement stats and renders it inline in the feed.
 * Never stacks multiple prompts — one, well-timed, dismissible.
 *
 * Pass `engagement` from useUpdates() and an `onBecomeCreator`
 * handler that routes to your Creator onboarding flow.
 */

const THRESHOLDS = [
  {
    key: 'followers',
    test: (e) => e.followers >= 100,
    emoji: '🔥',
    title: 'You\u2019re growing!',
    body: (e) => `${e.followers} people follow your updates. Unlock Creator Tools.`,
    cta: 'Become a Creator',
  },
  {
    key: 'views',
    test: (e) => e.lastPostViews >= 5000,
    emoji: '👀',
    title: 'People are watching.',
    body: (e) => `Your last update got ${e.lastPostViews.toLocaleString()} views. Turn this into a Creator Profile.`,
    cta: 'Start a Creator Profile',
  },
  {
    key: 'reactions',
    test: (e) => e.totalReactionsReceived >= 250,
    emoji: '❤️',
    title: 'Your updates are getting attention.',
    body: () => 'Start earning from your audience with subscriptions.',
    cta: 'Set up Subscriptions',
  },
  {
    key: 'live',
    test: (e) => e.liveRoomsJoined >= 5,
    emoji: '🎤',
    title: 'You spend a lot of time in Live.',
    body: () => 'Host your own room and bring your audience with you.',
    cta: 'Host a Live Room',
  },
];

export default function CreatorPromptBanner({ engagement, onBecomeCreator, onDismiss }) {
  const [dismissed, setDismissed] = React.useState(false);

  if (!engagement || dismissed) return null;

  const match = THRESHOLDS.find((t) => t.test(engagement));
  if (!match) return null;

  const handleDismiss = () => {
    setDismissed(true);
    onDismiss && onDismiss(match.key);
  };

  return (
    <View style={styles.card}>
      <TouchableOpacity style={styles.closeBtn} onPress={handleDismiss} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
        <Text style={styles.closeText}>✕</Text>
      </TouchableOpacity>
      <Text style={styles.emoji}>{match.emoji}</Text>
      <Text style={styles.title}>{match.title}</Text>
      <Text style={styles.body}>{match.body(engagement)}</Text>
      <TouchableOpacity
        style={styles.cta}
        activeOpacity={0.85}
        onPress={() => onBecomeCreator && onBecomeCreator(match.key)}
      >
        <Text style={styles.ctaText}>{match.cta} →</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#F4F1FF',
    borderRadius: 16,
    padding: 16,
    marginHorizontal: 14,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: '#E1D9FF',
  },
  closeBtn: {
    position: 'absolute',
    top: 10,
    right: 12,
    zIndex: 1,
  },
  closeText: {
    color: '#9A8FC7',
    fontSize: 14,
    fontWeight: '600',
  },
  emoji: {
    fontSize: 22,
    marginBottom: 4,
  },
  title: {
    fontSize: 15,
    fontWeight: '700',
    color: '#2B2140',
    marginBottom: 2,
  },
  body: {
    fontSize: 13,
    color: '#5B5270',
    marginBottom: 12,
    lineHeight: 18,
  },
  cta: {
    alignSelf: 'flex-start',
    backgroundColor: '#6C4EF5',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  ctaText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 13,
  },
});
