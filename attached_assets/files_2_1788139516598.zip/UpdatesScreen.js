import React, { useEffect, useState, useMemo } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  RefreshControl,
  SafeAreaView,
} from 'react-native';
import { UpdatesProvider, useUpdates } from '../context/UpdatesContext';
import PostCard from '../components/PostCard';
import CreatorPromptBanner from '../components/CreatorPromptBanner';
import CreateUpdateModal from '../components/CreateUpdateModal';

// Insert the creator prompt banner after this many posts in the feed
const PROMPT_INSERT_INDEX = 2;

function UpdatesFeedInner({ navigation }) {
  const { posts, loading, loadFeed, engagement } = useUpdates();
  const [refreshing, setRefreshing] = useState(false);
  const [composeOpen, setComposeOpen] = useState(false);
  const [promptDismissed, setPromptDismissed] = useState(false);

  useEffect(() => {
    loadFeed();
  }, [loadFeed]);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadFeed();
    setRefreshing(false);
  };

  const handleBecomeCreator = (triggerKey) => {
    // Wire this to your actual Creator onboarding flow / navigation
    navigation?.navigate?.('CreatorOnboarding', { trigger: triggerKey });
  };

  // Build feed data with the banner spliced in as a virtual list item
  const listData = useMemo(() => {
    if (promptDismissed || posts.length < PROMPT_INSERT_INDEX) {
      return posts.map((p) => ({ type: 'post', post: p }));
    }
    const items = posts.map((p) => ({ type: 'post', post: p }));
    items.splice(PROMPT_INSERT_INDEX, 0, { type: 'prompt' });
    return items;
  }, [posts, promptDismissed]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Updates</Text>
        <TouchableOpacity onPress={() => setComposeOpen(true)} style={styles.composeBtn}>
          <Text style={styles.composeBtnText}>+ New</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={listData}
        keyExtractor={(item, idx) => (item.type === 'prompt' ? 'creator-prompt' : item.post.id)}
        renderItem={({ item }) =>
          item.type === 'prompt' ? (
            <CreatorPromptBanner
              engagement={engagement}
              onBecomeCreator={handleBecomeCreator}
              onDismiss={() => setPromptDismissed(true)}
            />
          ) : (
            <PostCard post={item.post} />
          )
        }
        contentContainerStyle={styles.listContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListEmptyComponent={
          !loading && (
            <View style={styles.empty}>
              <Text style={styles.emptyText}>No updates yet. Be the first to post!</Text>
            </View>
          )
        }
      />

      <CreateUpdateModal
        visible={composeOpen}
        onClose={() => setComposeOpen(false)}
        isCreator={false /* flip to true once this user is a Creator */}
      />
    </SafeAreaView>
  );
}

// Public export: wraps the screen with its provider so it's a drop-in
// route/tab in your navigator. If you already have global state, you
// can lift UpdatesProvider higher in your tree and just export
// UpdatesFeedInner instead.
export default function UpdatesScreen(props) {
  return (
    <UpdatesProvider>
      <UpdatesFeedInner {...props} />
    </UpdatesProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: '#1A1A1A',
  },
  composeBtn: {
    backgroundColor: '#6C4EF5',
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 18,
  },
  composeBtnText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 13,
  },
  listContent: {
    paddingVertical: 8,
    paddingBottom: 24,
  },
  empty: {
    padding: 40,
    alignItems: 'center',
  },
  emptyText: {
    color: '#999',
    fontSize: 14,
  },
});
