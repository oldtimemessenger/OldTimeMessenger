import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Switch,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useUpdates } from '../context/UpdatesContext';

/**
 * CreateUpdateModal
 * -------------------------------------------------
 * Composer for a new update. `isCreator` controls whether the
 * "Subscribers only" toggle is shown at all — regular users don't
 * see monetization controls they can't use.
 */
export default function CreateUpdateModal({ visible, onClose, isCreator = false }) {
  const { addPost } = useUpdates();
  const [text, setText] = useState('');
  const [subscriberOnly, setSubscriberOnly] = useState(false);
  const [posting, setPosting] = useState(false);

  const handlePost = async () => {
    if (!text.trim()) return;
    setPosting(true);
    try {
      await addPost(text.trim(), subscriberOnly);
      setText('');
      setSubscriberOnly(false);
      onClose();
    } finally {
      setPosting(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.backdrop}
      >
        <View style={styles.sheet}>
          <View style={styles.handle} />
          <View style={styles.headerRow}>
            <TouchableOpacity onPress={onClose}>
              <Text style={styles.cancel}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.title}>New Update</Text>
            <TouchableOpacity onPress={handlePost} disabled={!text.trim() || posting}>
              <Text style={[styles.post, (!text.trim() || posting) && styles.postDisabled]}>
                {posting ? 'Posting…' : 'Post'}
              </Text>
            </TouchableOpacity>
          </View>

          <TextInput
            style={styles.input}
            placeholder="What's happening?"
            placeholderTextColor="#B0B0B0"
            multiline
            maxLength={500}
            value={text}
            onChangeText={setText}
            autoFocus
          />
          <Text style={styles.expiryNote}>Disappears in 24 hours · everyone can see this window</Text>

          {isCreator && (
            <View style={styles.toggleRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.toggleLabel}>Subscribers only</Text>
                <Text style={styles.toggleSubtext}>
                  Only your paying subscribers will be able to see this update.
                </Text>
              </View>
              <Switch value={subscriberOnly} onValueChange={setSubscriberOnly} />
            </View>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  sheet: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 16,
    paddingBottom: 28,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#DDD',
    alignSelf: 'center',
    marginBottom: 12,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  cancel: {
    color: '#888',
    fontSize: 15,
  },
  title: {
    fontWeight: '700',
    fontSize: 15,
  },
  post: {
    color: '#6C4EF5',
    fontWeight: '700',
    fontSize: 15,
  },
  postDisabled: {
    color: '#C9BEF7',
  },
  input: {
    minHeight: 90,
    fontSize: 16,
    color: '#1A1A1A',
    textAlignVertical: 'top',
  },
  expiryNote: {
    fontSize: 11.5,
    color: '#AAA',
    marginTop: 6,
    marginBottom: 4,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  toggleLabel: {
    fontSize: 14.5,
    fontWeight: '600',
    color: '#1A1A1A',
  },
  toggleSubtext: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
    paddingRight: 10,
  },
});
