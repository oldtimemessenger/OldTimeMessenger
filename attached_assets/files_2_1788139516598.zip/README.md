# Updates Feature — React Native

Drop-in implementation of the **Updates** section from your app plan. Built in three layers so you can wire them up incrementally.

## What's included

```
updates-feature/
├── context/UpdatesContext.js      # state + mock API (swap for real backend calls)
├── components/
│   ├── PostCard.js                # a single update: reactions, comments count, expiry timer
│   ├── SubscriptionGate.js        # blurs + locks subscriber-only posts, upsell CTA
│   ├── CreatorPromptBanner.js     # contextual "level up to Creator" nudges
│   └── CreateUpdateModal.js       # compose sheet, with subscriber-only toggle for creators
└── screens/UpdatesScreen.js       # ties it all together into one screen
```

## 1. Core feed
`UpdatesScreen` renders a `FlatList` of posts pulled from `UpdatesContext`. Each post:
- Shows author, avatar, creator badge
- Supports emoji reactions (tap "React" → pick emoji, toggles on/off)
- Shows a live "Xh left" countdown based on the 24-hour disappearing window from your original plan
- Pull-to-refresh

**To integrate:** add `UpdatesScreen` as a tab/route in your navigator. It's self-contained (wraps itself in `UpdatesProvider`), so it works standalone. If you already have global app state (Redux/Zustand/etc.), lift `UpdatesProvider` up and swap the `mockApi` object in `UpdatesContext.js` for real calls to your backend.

## 2. Creator upgrade prompts
`CreatorPromptBanner` reads an `engagement` object (`followers`, `lastPostViews`, `totalReactionsReceived`, `liveRoomsJoined`) and shows **one** relevant, dismissible nudge — matching the "not spammy, contextually placed" behavior from your plan. It's spliced into the feed as a virtual list item after the 2nd post (`PROMPT_INSERT_INDEX` in `UpdatesScreen.js`) rather than pinned to the top, so it feels native to the scroll rather than like an ad.

**To integrate:** replace `mockApi.fetchEngagement()` with a real call to your analytics/engagement service, and wire `handleBecomeCreator` in `UpdatesScreen.js` to your actual Creator onboarding navigation route.

## 3. Subscription gating
`SubscriptionGate` wraps subscriber-only posts. Non-subscribers see a blurred preview + "Subscribe · $X/mo" CTA rather than nothing at all — this is what drives conversion. `PostCard` already applies this automatically when `post.subscriberOnly` is true.

**To integrate:**
- Replace `mockApi.subscribeTo()` with your real subscription/payment flow (App Store/Google Play IAP for mobile — required by both platforms for digital subscriptions).
- `SubscriptionGate` uses `expo-blur`. If you're not on Expo, swap the `<BlurView>` for a plain `<View style={{ backgroundColor: 'rgba(0,0,0,0.55)' }} />` — visually similar without the dependency.

## Design notes
- Prices, thresholds, and copy are placeholders — tune `CreatorPromptBanner`'s `THRESHOLDS` array and `SubscriptionGate`'s hardcoded `"4.99"` to match your real pricing rules and creator-set prices.
- The mock data layer in `UpdatesContext.js` is fully functional standalone — you can run this today without a backend to demo the flow, then swap each `mockApi` method for a real fetch call one at a time.
- Payment/subscription logic here is UI-only. Real in-app purchases, payouts, and the 65/35 split need to go through Apple/Google IAP + a backend that reconciles entitlements — happy to help scaffold that next.

## Suggested next steps (in order)
1. Wire `mockApi` in `UpdatesContext.js` to your real backend endpoints
2. Add real auth-aware `isCreator` flag (currently hardcoded `false` in `UpdatesScreen`)
3. Hook `SubscriptionGate`'s `onSubscribe` to your IAP purchase flow
4. Build the Live Rooms and Campaigns screens as separate features using the same pattern
