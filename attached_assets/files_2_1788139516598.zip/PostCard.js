import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import SubscriptionGate from './SubscriptionGate';
import { useUpdates } from '../context/UpdatesContext';

const REACTION_OPTIONS = ['❤️', '🔥', '😂', '😮'];

function timeLeft(expiresAt) {
  const ms = expiresAt - Date.now();
  if (ms <= 0) return 'Expired';
  const hrs = Math.floor(ms / (1000 * 60 * 60));
  const mins = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
  return hrs > 0 ? `${hrs}h left` : `${mins}m left`;
}

function timeAgo(ts) {
  const mins = Math.floor((Date.now() - ts) / 60000);
  if (mins < 1) return 'now';
  if (mins < 60) return `${mins}m`;
  const hrs = Math.floor(mins / 60);
  return `${hrs}h`;
}

export default function PostCard({ post }) {
  const { react, isSubscribed, subscribeTo } = useUpdates();
  const [showReactions, setShowReactions] = React.useState(false);
  const subscribed = isSubscribed(post.authorId);

  const content = (
    <View style={styles.card}>
      <View style={styles.header}>
        <Image source={{ uri: post.authorAvatar }} style={styles.avatar} />
        <View style={{ flex: 1 }}>
          <View style={styles.nameRow}>
            <Text style={styles.name}>{post.authorName}</Text>
            {post.isCreator && <Text style={styles.creatorBadge}>⭐ Creator</Text>}
            {post.subscriberOnly && (
              <View style={styles.subBadge}>
                <Text style={styles.subBadgeText}>Subscribers</Text>
              </View>
            )}
          </View>
          <Text style={styles.meta}>
            {timeAgo(post.createdAt)} · {timeLeft(post.expiresAt)}
          </Text>
        </View>
      </View>

      <Text style={styles.text}>{post.text}</Text>

      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.reactBtn}
          onPress={() => setShowReactions((s) => !s)}
          activeOpacity={0.7}
        >
          <Text style={styles.reactBtnText}>
            {post.myReaction ? post.myReaction : '🙂'} React
          </Text>
        </TouchableOpacity>

        <View style={styles.reactionCounts}>
          {Object.entries(post.reactions)
            .filter(([, count]) => count > 0)
            .map(([emoji, count]) => (
              <Text key={emoji} style={styles.reactionCount}>
                {emoji} {count}
              </Text>
            ))}
        </View>

        <Text style={styles.commentCount}>💬 {post.commentCount}</Text>
      </View>

      {showReactions && (
        <View style={styles.reactionPicker}>
          {REACTION_OPTIONS.map((emoji) => (
            <TouchableOpacity
              key={emoji}
              onPress={() => {
                react(post.id, emoji);
                setShowReactions(false);
              }}
              style={styles.reactionOption}
            >
              <Text style={styles.reactionOptionEmoji}>{emoji}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </View>
  );

  if (post.subscriberOnly) {
    return (
      <SubscriptionGate
        isSubscribed={subscribed}
        price="4.99"
        creatorName={post.authorName}
        onSubscribe={() => subscribeTo(post.authorId)}
      >
        {content}
      </SubscriptionGate>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 14,
    marginHorizontal: 14,
    marginVertical: 6,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  name: {
    fontWeight: '700',
    fontSize: 14.5,
    color: '#1A1A1A',
    marginRight: 6,
  },
  creatorBadge: {
    fontSize: 11.5,
    color: '#B8860B',
    fontWeight: '600',
    marginRight: 6,
  },
  subBadge: {
    backgroundColor: '#EDE7FF',
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 8,
  },
  subBadgeText: {
    fontSize: 10.5,
    color: '#6C4EF5',
    fontWeight: '700',
  },
  meta: {
    fontSize: 11.5,
    color: '#9A9A9A',
    marginTop: 1,
  },
  text: {
    fontSize: 14.5,
    color: '#2A2A2A',
    lineHeight: 20,
    marginBottom: 10,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  reactBtn: {
    paddingVertical: 5,
    paddingHorizontal: 10,
    backgroundColor: '#F5F5F7',
    borderRadius: 16,
  },
  reactBtnText: {
    fontSize: 12.5,
    color: '#444',
    fontWeight: '600',
  },
  reactionCounts: {
    flexDirection: 'row',
    gap: 8,
  },
  reactionCount: {
    fontSize: 12.5,
    color: '#666',
  },
  commentCount: {
    fontSize: 12.5,
    color: '#666',
  },
  reactionPicker: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  reactionOption: {
    padding: 6,
  },
  reactionOptionEmoji: {
    fontSize: 24,
  },
});
